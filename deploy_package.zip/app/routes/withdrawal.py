import logging
"""
withdrawal.py — Vendor Withdrawal Routes
Handles bank accounts, withdrawal requests, and POD payments
"""
import os
import requests
from datetime import datetime, timezone
from decimal import Decimal

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy import func

from app.extensions import db
from app.models.withdrawal import VendorBankAccount, Withdrawal, PODPayment, PartnerBankAccount, PartnerWithdrawal
from app.models.order import Order
from app.models.finance import Ledger
from app.models.communication import Notification
from app.models.user import User

withdrawal_bp = Blueprint('withdrawal', __name__)

PAYSTACK_SECRET_KEY = os.environ.get('PAYSTACK_SECRET_KEY', '')
PAYSTACK_BASE_URL = 'https://api.paystack.co'


def _utcnow():
    return datetime.now(timezone.utc)


def _get_ledger_balance(vendor_id: int) -> Decimal:
    """Calculate vendor's available ledger balance"""
    credits = db.session.query(func.sum(Ledger.amount)).filter_by(
        vendor_id=vendor_id, transaction_type='CREDIT'
    ).scalar() or Decimal('0')
    
    debits = db.session.query(func.sum(Ledger.amount)).filter_by(
        vendor_id=vendor_id, transaction_type='DEBIT'
    ).scalar() or Decimal('0')
    
    return Decimal(str(credits)) - Decimal(str(debits))


def _debit_ledger(vendor_id: int, amount: Decimal, description: str, reference_id: str):
    """Write a DEBIT entry to vendor's ledger"""
    balance = _get_ledger_balance(vendor_id)
    balance_after = balance - amount
    
    db.session.add(Ledger(
        vendor_id=vendor_id,
        transaction_type='DEBIT',
        amount=amount,
        description=description,
        reference_id=reference_id,
        balance_after=balance_after,
    ))


# ---------------------------------------------------------------------------
# BANK ACCOUNT MANAGEMENT
# ---------------------------------------------------------------------------


@withdrawal_bp.route('/bank-accounts', methods=['GET'])
@jwt_required()
def get_bank_accounts():
    """Get vendor's bank accounts"""
    vendor_id = get_jwt_identity()
    accounts = VendorBankAccount.query.filter_by(vendor_id=vendor_id).all()
    return jsonify({
        'status': 'success',
        'accounts': [acc.to_dict() for acc in accounts]
    }), 200


@withdrawal_bp.route('/bank-accounts', methods=['POST'])
@jwt_required()
def add_bank_account():
    """Add and verify a new bank account"""
    vendor_id = get_jwt_identity()
    data = request.get_json() or {}
    
    bank_code = data.get('bank_code')
    account_number = data.get('account_number')
    
    if not bank_code or not account_number:
        return jsonify({'message': 'bank_code and account_number required'}), 400
    
    # Normalize bank codes for Paystack and CBN/Daya
    from app.services.escrow.paystack_provider import NIBSS_TO_PAYSTACK_BANKS, PAYSTACK_TO_NIBSS_BANKS
    paystack_bank_code = NIBSS_TO_PAYSTACK_BANKS.get(str(bank_code).strip(), str(bank_code).strip())
    cbn_bank_code = PAYSTACK_TO_NIBSS_BANKS.get(str(bank_code).strip(), str(bank_code).strip())

    # Verify account with Paystack
    is_test_mode = PAYSTACK_SECRET_KEY.startswith('sk_test_')
    try:
        headers = {
            'Authorization': f'Bearer {PAYSTACK_SECRET_KEY}',
            'Content-Type': 'application/json'
        }

        bank_name = data.get('bank_name', 'Bank')

        if is_test_mode:
            # Paystack /bank/resolve only works with LIVE keys and real accounts.
            # In test mode we skip resolution and use the submitted bank name as the account name.
            logging.info(f'[BANK ACCOUNT] Test mode: skipping account name resolution for {account_number}')
            account_name = bank_name  # placeholder — replaced with real name once live key is used
        else:
            # 1. Resolve account name (live mode only)
            resolve_url = f'{PAYSTACK_BASE_URL}/bank/resolve'
            resolve_params = {
                'account_number': account_number,
                'bank_code': paystack_bank_code
            }
            resolve_response = requests.get(resolve_url, headers=headers, params=resolve_params, timeout=10)
            resolve_data = resolve_response.json()

            if not resolve_data.get('status'):
                return jsonify({'message': 'Could not verify account. Please check your account number and bank.'}), 400

            account_name = resolve_data['data']['account_name']
        
        # 2. Create transfer recipient
        recipient_url = f'{PAYSTACK_BASE_URL}/transferrecipient'
        recipient_payload = {
            'type': 'nuban',
            'name': account_name,
            'account_number': account_number,
            'bank_code': paystack_bank_code,
            'currency': 'NGN'
        }
        recipient_response = requests.post(recipient_url, headers=headers, json=recipient_payload, timeout=10)
        recipient_data = recipient_response.json()
        
        if not recipient_data.get('status'):
            return jsonify({'message': 'Could not create recipient. Please try again.'}), 400
        
        recipient_code = recipient_data['data']['recipient_code']
        
        # 3. Check if account already exists
        existing = VendorBankAccount.query.filter_by(
            vendor_id=vendor_id,
            account_number=account_number,
        ).first()
        
        if existing:
            # Update recipient_code and details on existing record
            existing.recipient_code = recipient_code
            existing.bank_name = bank_name or existing.bank_name
            existing.bank_code = cbn_bank_code or existing.bank_code
            existing.account_name = account_name or existing.account_name
            db.session.commit()
            return jsonify({
                'status': 'success',
                'message': 'Bank account updated successfully',
                'account': existing.to_dict()
            }), 200
        
        # 4. Create bank account record (save CBN code for Daya + recipient_code for Paystack)
        is_first = VendorBankAccount.query.filter_by(vendor_id=vendor_id).count() == 0
        
        bank_account = VendorBankAccount(
            vendor_id=vendor_id,
            bank_name=bank_name,
            bank_code=cbn_bank_code,
            account_number=account_number,
            account_name=account_name,
            recipient_code=recipient_code,
            is_verified=True,
            verified_at=_utcnow(),
            is_default=is_first  # First account is default
        )
        
        db.session.add(bank_account)
        db.session.flush()  # Get bank_account.id without committing yet

        # ── Create Paystack subaccount for Split Payments ──────────────────
        # Register the vendor's bank account as a Paystack subaccount so
        # digital/service checkouts can split the payment natively.
        try:
            from app.services.escrow.paystack_provider import create_paystack_subaccount
            from app.models.user import Storefront
            storefront = Storefront.query.filter_by(vendor_id=vendor_id).first()
            business_name = (storefront.store_name if storefront else account_name)
            sub_result = create_paystack_subaccount(
                business_name=business_name,
                bank_code=bank_code,
                account_number=account_number,
            )
            if sub_result.get("success"):
                subaccount_code = sub_result["subaccount_code"]
                bank_account.paystack_subaccount_code = subaccount_code
                # Also update the storefront so checkout can find it via either lookup
                if storefront:
                    storefront.paystack_subaccount_code = subaccount_code
                logging.info(
                    f"[BANK ACCOUNT] Paystack subaccount {subaccount_code} "
                    f"saved for vendor {vendor_id}"
                )
            else:
                logging.warning(
                    f"[BANK ACCOUNT] Paystack subaccount creation failed for vendor {vendor_id}: "
                    f"{sub_result.get('error_message')}"
                )
        except Exception as _sub_exc:
            logging.warning(
                f"[BANK ACCOUNT] Paystack subaccount error for vendor {vendor_id}: {_sub_exc}"
            )

        # ── Create Flutterwave subaccount for Split Payments ───────────────
        # Best-effort — if it fails, Paystack and Daya payouts still work.
        # Flutterwave subaccount is used when buyers pay via Flutterwave
        # (international cards, local cards). The RS_xxx ID is stored on the
        # bank account record and looked up at checkout time.
        try:
            from app.services.flutterwave_service import create_subaccount as _flw_create_sub, is_configured as _flw_configured
            if _flw_configured():
                # Storefront is already loaded above; safe to reuse
                _flw_business_name = (storefront.store_name if storefront else account_name)
                _flw_phone = ""
                if storefront:
                    try:
                        from app.models.user import User as _U
                        _vendor_user = db.session.get(_U, int(vendor_id))
                        _flw_phone = (_vendor_user.phone or "") if _vendor_user else ""
                    except Exception:
                        pass

                flw_result = _flw_create_sub(
                    business_name=_flw_business_name,
                    # Flutterwave uses the same CBN bank code as Daya
                    bank_code=cbn_bank_code,
                    account_number=account_number,
                    business_mobile=_flw_phone or "08012345678",
                    business_email=(storefront.contact_email if storefront and storefront.contact_email else ""),
                )
                if flw_result.get("success"):
                    bank_account.flw_subaccount_id = flw_result["subaccount_id"]
                    logging.info(
                        "[BANK ACCOUNT] Flutterwave subaccount %s saved for vendor %s",
                        flw_result["subaccount_id"], vendor_id,
                    )
                else:
                    logging.warning(
                        "[BANK ACCOUNT] Flutterwave subaccount creation failed for vendor %s: %s",
                        vendor_id, flw_result.get("error_message"),
                    )
            else:
                logging.info("[BANK ACCOUNT] Flutterwave not configured — skipping FLW subaccount creation")
        except Exception as _flw_exc:
            logging.warning(
                "[BANK ACCOUNT] Flutterwave subaccount error for vendor %s: %s",
                vendor_id, _flw_exc,
            )

        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Bank account added and verified successfully',
            'account': bank_account.to_dict()
        }), 201
        
    except requests.exceptions.RequestException as e:
        return jsonify({'message': f'Verification failed: {str(e)}'}), 500
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Error: {str(e)}'}), 500



@withdrawal_bp.route('/bank-accounts/<int:account_id>/set-default', methods=['PATCH'])
@jwt_required()
def set_default_account(account_id):
    """Set a bank account as default"""
    vendor_id = get_jwt_identity()
    
    account = db.session.get(VendorBankAccount, account_id)
    if not account or account.vendor_id != int(vendor_id):
        return jsonify({'message': 'Account not found'}), 404
    
    # Remove default from all accounts
    VendorBankAccount.query.filter_by(vendor_id=vendor_id).update({'is_default': False})
    
    # Set this as default
    account.is_default = True
    db.session.commit()
    
    return jsonify({
        'status': 'success',
        'message': 'Default account updated'
    }), 200


@withdrawal_bp.route('/bank-accounts/<int:account_id>', methods=['DELETE'])
@jwt_required()
def delete_bank_account(account_id):
    """Delete a bank account"""
    vendor_id = get_jwt_identity()
    
    account = db.session.get(VendorBankAccount, account_id)
    if not account or account.vendor_id != int(vendor_id):
        return jsonify({'message': 'Account not found'}), 404
    
    # Can't delete if it's the only account and there are pending withdrawals
    if account.is_default:
        other_accounts = VendorBankAccount.query.filter(
            VendorBankAccount.vendor_id == vendor_id,
            VendorBankAccount.id != account_id
        ).first()
        
        if other_accounts:
            other_accounts.is_default = True
    
    db.session.delete(account)
    db.session.commit()
    
    return jsonify({
        'status': 'success',
        'message': 'Bank account deleted'
    }), 200


# ---------------------------------------------------------------------------
# WITHDRAWAL REQUESTS
# ---------------------------------------------------------------------------

@withdrawal_bp.route('/balance', methods=['GET'])
@jwt_required()
def get_balance():
    """Get vendor's available balance"""
    vendor_id = get_jwt_identity()
    balance = _get_ledger_balance(vendor_id)
    
    # Get pending withdrawals
    pending_amount = db.session.query(func.sum(Withdrawal.amount)).filter_by(
        vendor_id=vendor_id,
        status='PENDING'
    ).scalar() or Decimal('0')
    
    available = balance - Decimal(str(pending_amount))
    
    return jsonify({
        'status': 'success',
        'balance': str(balance),
        'pending_withdrawals': str(pending_amount),
        'available': str(available),
        'currency': 'NGN'
    }), 200


@withdrawal_bp.route('/withdrawals', methods=['GET'])
@jwt_required()
def get_withdrawals():
    """Get vendor's withdrawal history"""
    vendor_id = get_jwt_identity()
    page = int(request.args.get('page', 1))
    per_page = min(int(request.args.get('per_page', 20)), 100)
    
    paginated = Withdrawal.query.filter_by(vendor_id=vendor_id).order_by(
        Withdrawal.requested_at.desc()
    ).paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'status': 'success',
        'withdrawals': [w.to_dict() for w in paginated.items],
        'total': paginated.total,
        'pages': paginated.pages,
        'page': page
    }), 200


@withdrawal_bp.route('/withdrawals', methods=['POST'])
@jwt_required()
def request_withdrawal():
    """
    Vendor requests a withdrawal.

    With Paystack provider: triggers a Paystack transfer to the vendor's
    default bank account using the stored recipient_code.

    With Payscrow provider: returns 400 (split settlement is automatic).
    """
    from app.services import flutterwave_service as _flw
    provider = os.environ.get("ACTIVE_ESCROW_PROVIDER", "payscrow").lower()
    has_flw = _flw.is_configured()
    has_paystack = (provider == "paystack") or bool(PAYSTACK_SECRET_KEY)

    if not has_flw and not has_paystack:
        return jsonify({
            'message': (
                'Manual withdrawals are currently deactivated. '
                'Escrow payouts are processed automatically upon delivery confirmation.'
            )
        }), 400

    vendor_id = get_jwt_identity()

    # Check available balance
    balance = _get_ledger_balance(int(vendor_id))
    pending_amount = db.session.query(func.sum(Withdrawal.amount)).filter_by(
        vendor_id=vendor_id,
        status='PENDING',
    ).scalar() or Decimal('0')
    available = balance - Decimal(str(pending_amount))

    MIN_WITHDRAWAL = Decimal('1000')  # ₦1,000 minimum
    if available < MIN_WITHDRAWAL:
        return jsonify({
            'message': f'Insufficient balance. Minimum withdrawal is ₦{MIN_WITHDRAWAL:,.2f}. '
                       f'Your available balance is ₦{available:,.2f}.'
        }), 400

    # Get vendor's default bank account
    bank_acc = VendorBankAccount.query.filter_by(
        vendor_id=vendor_id, is_default=True
    ).first()
    if not bank_acc:
        bank_acc = VendorBankAccount.query.filter_by(vendor_id=vendor_id).first()

    if not bank_acc or not bank_acc.account_number or not bank_acc.bank_code:
        return jsonify({
            'message': 'No verified bank account found. '
                       'Please add and verify a bank account in your payout settings first.'
        }), 400

    data = request.get_json() or {}
    requested_amount = data.get('amount')
    if requested_amount:
        try:
            requested_amount = Decimal(str(requested_amount))
            if requested_amount <= 0 or requested_amount > available:
                return jsonify({'message': 'Invalid withdrawal amount.'}), 400
        except Exception:
            return jsonify({'message': 'Invalid amount format.'}), 400
    else:
        requested_amount = available  # default: withdraw all

    import uuid as _uuid
    reference = f"WD-{_uuid.uuid4().hex[:12].upper()}"
    transfer_code = ""

    # Primary transfer channel: Flutterwave if configured, else Paystack
    if has_flw:
        flw_res = _flw.transfer_to_vendor(
            account_bank=bank_acc.bank_code,
            account_number=bank_acc.account_number,
            amount_ngn=float(requested_amount),
            reference=reference,
            narration="Siiqo vendor withdrawal",
        )
        if not flw_res.get("success"):
            # If Flutterwave rejected and Paystack is available with recipient_code, try Paystack fallback
            if has_paystack and bank_acc.recipient_code:
                from app.services.escrow.paystack_provider import paystack_transfer_to_vendor
                result = paystack_transfer_to_vendor(
                    recipient_code=bank_acc.recipient_code,
                    amount_ngn=float(requested_amount),
                    reference=reference,
                    reason="Siiqo vendor withdrawal",
                )
                if not result.get("success"):
                    return jsonify({
                        'message': f"Withdrawal failed: {result.get('error_message', flw_res.get('error_message'))}"
                    }), 400
                transfer_code = result.get("transfer_code", "")
            else:
                return jsonify({
                    'message': f"Withdrawal failed: {flw_res.get('error_message', 'Payment gateway error')}"
                }), 400
        else:
            transfer_code = flw_res.get("transfer_id", "")
    elif has_paystack:
        if not bank_acc.recipient_code:
            return jsonify({'message': 'Paystack recipient not set up for this bank account.'}), 400
        from app.services.escrow.paystack_provider import paystack_transfer_to_vendor
        result = paystack_transfer_to_vendor(
            recipient_code=bank_acc.recipient_code,
            amount_ngn=float(requested_amount),
            reference=reference,
            reason="Siiqo vendor withdrawal",
        )
        if not result.get("success"):
            return jsonify({
                'message': f"Withdrawal failed: {result.get('error_message', 'Unknown error.')}"
            }), 400
        transfer_code = result.get("transfer_code", "")

    # Record withdrawal + debit ledger
    # Note: transfer_code is already set in each branch above (flw_res or result).
    new_withdrawal = Withdrawal(
        vendor_id=int(vendor_id),
        amount=requested_amount,
        fee_amount=Decimal('0'),
        net_amount=requested_amount,
        status='PENDING',
        bank_account_id=bank_acc.id,
        transfer_code=transfer_code,
        transfer_reference=reference,
    )
    db.session.add(new_withdrawal)

    _debit_ledger(
        vendor_id=int(vendor_id),
        amount=requested_amount,
        description=f"Withdrawal to {bank_acc.bank_name} {bank_acc.account_number[-4:]}",
        reference_id=reference,
    )

    db.session.commit()

    return jsonify({
        'status': 'success',
        'message': 'Withdrawal initiated. Funds will arrive within 24 hours.',
        'transfer_code': transfer_code,
        'amount': str(requested_amount),
    }), 200


# ---------------------------------------------------------------------------
# PAY ON DELIVERY (POD) MANAGEMENT
# ---------------------------------------------------------------------------

@withdrawal_bp.route('/pod-payments', methods=['GET'])
@jwt_required()
def get_pod_payments():
    """Get vendor's POD payments"""
    vendor_id = get_jwt_identity()
    page = int(request.args.get('page', 1))
    per_page = min(int(request.args.get('per_page', 20)), 100)
    status = request.args.get('status')  # confirmed, pending, reconciled
    
    query = PODPayment.query.filter_by(vendor_id=vendor_id)
    
    if status == 'confirmed':
        query = query.filter_by(confirmed_by_vendor=True, reconciled=False)
    elif status == 'pending':
        query = query.filter_by(confirmed_by_vendor=False)
    elif status == 'reconciled':
        query = query.filter_by(reconciled=True)
    
    paginated = query.order_by(PODPayment.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'status': 'success',
        'payments': [p.to_dict() for p in paginated.items],
        'total': paginated.total,
        'pages': paginated.pages,
        'page': page
    }), 200


@withdrawal_bp.route('/pod-payments/<int:order_id>/confirm', methods=['POST'])
@jwt_required()
def confirm_pod_payment(order_id):
    """Vendor confirms cash payment received"""
    vendor_id = get_jwt_identity()
    data = request.get_json() or {}
    
    # Get order
    order = db.session.get(Order, order_id)
    if not order:
        return jsonify({'message': 'Order not found'}), 404
    
    if order.vendor_id != int(vendor_id):
        return jsonify({'message': 'Unauthorized'}), 403
    
    # Get or create POD payment record
    pod_payment = PODPayment.query.filter_by(order_id=order_id).first()
    
    if not pod_payment:
        pod_payment = PODPayment(
            order_id=order_id,
            vendor_id=vendor_id,
            amount=order.total_amount,
            currency='NGN'
        )
        db.session.add(pod_payment)
    
    # Confirm payment
    pod_payment.confirmed_by_vendor = True
    pod_payment.confirmed_at = _utcnow()
    pod_payment.payment_method = data.get('payment_method', 'CASH')
    pod_payment.vendor_notes = data.get('notes', '')
    
    # Update order status
    order.status = 'COMPLETED'
    
    try:
        from app.services.referral_service import check_and_reward_referral_on_order_complete
        check_and_reward_referral_on_order_complete(order)
    except Exception as ex:
        logging.error(f"[REFERRAL ERR] POD vendor confirm referral reward failed: {ex}")
    
    # Credit vendor ledger (no platform fee for POD)
    from app.routes.escrow import _credit_vendor_ledger
    _credit_vendor_ledger(
        vendor_id=vendor_id,
        amount=float(order.total_amount),
        reference_id=f'POD-{order.id}',
        description=f'POD payment for Order #{order.id}'
    )
    
    # Notify buyer
    if order.buyer_id:
        db.session.add(Notification(
            user_id=order.buyer_id,
            title='Order Completed',
            message=f'Order #{order.id} has been completed. Thank you for shopping!',
            type='ORDER',
            order_id=order.id
        ))
    
    db.session.commit()
    
    return jsonify({
        'status': 'success',
        'message': 'Payment confirmed successfully',
        'payment': pod_payment.to_dict()
    }), 200


@withdrawal_bp.route('/pod-payments/summary', methods=['GET'])
@jwt_required()
def get_pod_summary():
    """Get POD payment summary for vendor"""
    vendor_id = get_jwt_identity()
    
    total_pending = db.session.query(func.sum(PODPayment.amount)).filter_by(
        vendor_id=vendor_id,
        confirmed_by_vendor=False
    ).scalar() or Decimal('0')
    
    total_confirmed = db.session.query(func.sum(PODPayment.amount)).filter_by(
        vendor_id=vendor_id,
        confirmed_by_vendor=True,
        reconciled=False
    ).scalar() or Decimal('0')
    
    total_reconciled = db.session.query(func.sum(PODPayment.amount)).filter_by(
        vendor_id=vendor_id,
        reconciled=True
    ).scalar() or Decimal('0')
    
    pending_count = PODPayment.query.filter_by(
        vendor_id=vendor_id,
        confirmed_by_vendor=False
    ).count()
    
    return jsonify({
        'status': 'success',
        'summary': {
            'total_pending': str(total_pending),
            'total_confirmed': str(total_confirmed),
            'total_reconciled': str(total_reconciled),
            'pending_count': pending_count,
            'currency': 'NGN'
        }
    }), 200


# ---------------------------------------------------------------------------
# PAYSTACK BANKS LIST
# ---------------------------------------------------------------------------

@withdrawal_bp.route('/banks', methods=['GET'])
def get_banks():
    """Get list of Nigerian banks from Paystack — public, no auth required"""
    try:
        headers = {
            'Authorization': f'Bearer {PAYSTACK_SECRET_KEY}',
        }
        
        response = requests.get(
            f'{PAYSTACK_BASE_URL}/bank',
            headers=headers,
            params={'country': 'nigeria', 'perPage': 200},
            timeout=10
        )
        
        data = response.json()
        
        if data.get('status') and data.get('data'):
            banks = [
                {'name': b['name'], 'code': b['code']}
                for b in data['data']
            ]
            # Sort alphabetically
            banks.sort(key=lambda x: x['name'])
            return jsonify({
                'status': 'success',
                'banks': banks
            }), 200
        else:
            logging.warning(f'[BANKS] Paystack returned no data: {data}')
            return jsonify({'status': 'success', 'banks': []}), 200
            
    except Exception as e:
        logging.warning(f'[BANKS] Error fetching bank list: {e}')
        return jsonify({'status': 'success', 'banks': []}), 200


@withdrawal_bp.route('/banks/resolve', methods=['GET'])
def resolve_bank_account():
    """
    Resolve (verify) a bank account name — public endpoint.
    Used by the partner apply form and vendor onboarding to auto-fill account name.
    Query params: bank_code, account_number
    """
    bank_code      = (request.args.get('bank_code') or '').strip()
    account_number = (request.args.get('account_number') or '').strip()

    if not bank_code or not account_number:
        return jsonify({'message': 'bank_code and account_number are required'}), 400

    if len(account_number) != 10:
        return jsonify({'message': 'Account number must be exactly 10 digits'}), 400

    try:
        headers = {
            'Authorization': f'Bearer {PAYSTACK_SECRET_KEY}',
            'Content-Type': 'application/json',
        }
        resp = requests.get(
            f'{PAYSTACK_BASE_URL}/bank/resolve',
            headers=headers,
            params={'account_number': account_number, 'bank_code': bank_code},
            timeout=10,
        )
        data = resp.json()

        if not data.get('status'):
            return jsonify({
                'message': data.get('message', 'Could not verify account. Check details.'),
                'account_name': None,
            }), 400

        return jsonify({
            'status': 'success',
            'account_name': data['data']['account_name'],
            'account_number': data['data']['account_number'],
        }), 200

    except requests.exceptions.RequestException as e:
        return jsonify({'message': f'Verification failed: {str(e)}'}), 500
    except Exception as e:
        return jsonify({'message': f'Error: {str(e)}'}), 500


# ---------------------------------------------------------------------------
# LOGISTICS PARTNER BANK ACCOUNT MANAGEMENT & WITHDRAWALS
# ---------------------------------------------------------------------------

@withdrawal_bp.route('/partner/bank-accounts', methods=['GET'])
@jwt_required()
def get_partner_bank_accounts():
    """Get partner's bank accounts"""
    partner_id = get_jwt_identity()
    accounts = PartnerBankAccount.query.filter_by(partner_id=partner_id).all()
    return jsonify({
        'status': 'success',
        'accounts': [acc.to_dict() for acc in accounts]
    }), 200


@withdrawal_bp.route('/partner/bank-accounts', methods=['POST'])
@jwt_required()
def add_partner_bank_account():
    """Add and verify a new partner bank account"""
    partner_id = get_jwt_identity()
    data = request.get_json() or {}
    
    bank_code = data.get('bank_code')
    account_number = data.get('account_number')
    
    if not bank_code or not account_number:
        return jsonify({'message': 'bank_code and account_number required'}), 400
    
    try:
        headers = {
            'Authorization': f'Bearer {PAYSTACK_SECRET_KEY}',
            'Content-Type': 'application/json'
        }
        
        # 1. Resolve account name
        resolve_url = f'{PAYSTACK_BASE_URL}/bank/resolve'
        resolve_params = {
            'account_number': account_number,
            'bank_code': bank_code
        }
        resolve_response = requests.get(resolve_url, headers=headers, params=resolve_params, timeout=10)
        resolve_data = resolve_response.json()
        
        if not resolve_data.get('status'):
            return jsonify({'message': 'Could not verify account. Please check details.'}), 400
        
        account_name = resolve_data['data']['account_name']
        bank_name = data.get('bank_name', 'Bank')
        
        # 2. Create transfer recipient
        recipient_url = f'{PAYSTACK_BASE_URL}/transferrecipient'
        recipient_payload = {
            'type': 'nuban',
            'name': account_name,
            'account_number': account_number,
            'bank_code': bank_code,
            'currency': 'NGN'
        }
        recipient_response = requests.post(recipient_url, headers=headers, json=recipient_payload, timeout=10)
        recipient_data = recipient_response.json()
        
        if not recipient_data.get('status'):
            return jsonify({'message': 'Could not create recipient. Please try again.'}), 400
        
        recipient_code = recipient_data['data']['recipient_code']
        
        # 3. Check if account already exists
        existing = PartnerBankAccount.query.filter_by(
            partner_id=partner_id,
            account_number=account_number,
            bank_code=bank_code
        ).first()
        
        if existing:
            return jsonify({'message': 'This bank account is already added'}), 400
        
        # 4. Create bank account record
        is_first = PartnerBankAccount.query.filter_by(partner_id=partner_id).count() == 0
        
        bank_account = PartnerBankAccount(
            partner_id=partner_id,
            bank_name=bank_name,
            bank_code=bank_code,
            account_number=account_number,
            account_name=account_name,
            recipient_code=recipient_code,
            is_verified=True,
            verified_at=_utcnow(),
            is_default=is_first  # First account is default
        )
        
        db.session.add(bank_account)
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Bank account added and verified successfully',
            'account': bank_account.to_dict()
        }), 201
        
    except requests.exceptions.RequestException as e:
        return jsonify({'message': f'Verification failed: {str(e)}'}), 500
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Error: {str(e)}'}), 500


@withdrawal_bp.route('/partner/bank-accounts/<int:account_id>/set-default', methods=['PATCH'])
@jwt_required()
def set_default_partner_account(account_id):
    """Set a partner bank account as default"""
    partner_id = get_jwt_identity()
    
    account = db.session.get(PartnerBankAccount, account_id)
    if not account or account.partner_id != int(partner_id):
        return jsonify({'message': 'Account not found'}), 404
    
    # Remove default from all accounts
    PartnerBankAccount.query.filter_by(partner_id=partner_id).update({'is_default': False})
    
    # Set this as default
    account.is_default = True
    db.session.commit()
    
    return jsonify({
        'status': 'success',
        'message': 'Default account updated'
    }), 200


@withdrawal_bp.route('/partner/bank-accounts/<int:account_id>', methods=['DELETE'])
@jwt_required()
def delete_partner_bank_account(account_id):
    """Delete a partner bank account"""
    partner_id = get_jwt_identity()
    
    account = db.session.get(PartnerBankAccount, account_id)
    if not account or account.partner_id != int(partner_id):
        return jsonify({'message': 'Account not found'}), 404
    
    if account.is_default:
        other_accounts = PartnerBankAccount.query.filter(
            PartnerBankAccount.partner_id == partner_id,
            PartnerBankAccount.id != account_id
        ).first()
        
        if other_accounts:
            other_accounts.is_default = True
    
    db.session.delete(account)
    db.session.commit()
    
    return jsonify({
        'status': 'success',
        'message': 'Bank account deleted'
    }), 200


@withdrawal_bp.route('/partner/balance', methods=['GET'])
@jwt_required()
def get_partner_balance():
    """Get logistics partner's available balance"""
    partner_id = get_jwt_identity()
    
    from app.models.escrow import LogisticsAssignment
    from app.models.withdrawal import PartnerWithdrawal
    
    total_earned = db.session.query(func.sum(LogisticsAssignment.delivery_fee)).filter_by(
        partner_id=partner_id, status='DELIVERED'
    ).scalar() or Decimal('0')
    
    # Sum of successfully completed or pending withdrawals
    withdrawn_amount = db.session.query(func.sum(PartnerWithdrawal.amount)).filter(
        PartnerWithdrawal.partner_id == partner_id,
        PartnerWithdrawal.status.in_(['PENDING', 'PROCESSING', 'COMPLETED'])
    ).scalar() or Decimal('0')
    
    available = Decimal(str(total_earned)) - Decimal(str(withdrawn_amount))
    
    return jsonify({
        'status': 'success',
        'balance': str(total_earned),
        'pending_withdrawals': str(withdrawn_amount),
        'available': str(available),
        'currency': 'NGN'
    }), 200


@withdrawal_bp.route('/partner/withdrawals', methods=['GET'])
@jwt_required()
def get_partner_withdrawals():
    """Get partner's withdrawal history"""
    partner_id = get_jwt_identity()
    page = int(request.args.get('page', 1))
    per_page = min(int(request.args.get('per_page', 20)), 100)
    
    paginated = PartnerWithdrawal.query.filter_by(partner_id=partner_id).order_by(
        PartnerWithdrawal.requested_at.desc()
    ).paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'status': 'success',
        'withdrawals': [w.to_dict() for w in paginated.items],
        'total': paginated.total,
        'pages': paginated.pages,
        'page': page
    }), 200


@withdrawal_bp.route('/partner/withdrawals', methods=['POST'])
@jwt_required()
def request_partner_withdrawal():
    """Partner requests a withdrawal. Triggers a Paystack transfer."""
    partner_id = get_jwt_identity()

    # Calculate available balance
    from app.models.escrow import LogisticsAssignment
    from app.models.withdrawal import PartnerWithdrawal
    
    total_earned = db.session.query(func.sum(LogisticsAssignment.delivery_fee)).filter_by(
        partner_id=partner_id, status='DELIVERED'
    ).scalar() or Decimal('0')
    
    withdrawn_amount = db.session.query(func.sum(PartnerWithdrawal.amount)).filter(
        PartnerWithdrawal.partner_id == partner_id,
        PartnerWithdrawal.status.in_(['PENDING', 'PROCESSING', 'COMPLETED'])
    ).scalar() or Decimal('0')
    
    available = Decimal(str(total_earned)) - Decimal(str(withdrawn_amount))

    MIN_WITHDRAWAL = Decimal('1000')  # ₦1,000 minimum
    if available < MIN_WITHDRAWAL:
        return jsonify({
            'message': f'Insufficient balance. Minimum withdrawal is ₦{MIN_WITHDRAWAL:,.2f}. '
                       f'Your available balance is ₦{available:,.2f}.'
        }), 400

    # Get default bank account
    bank_acc = PartnerBankAccount.query.filter_by(
        partner_id=partner_id, is_default=True
    ).first()
    if not bank_acc:
        bank_acc = PartnerBankAccount.query.filter_by(partner_id=partner_id).first()

    if not bank_acc or not bank_acc.recipient_code:
        return jsonify({
            'message': 'No verified bank account found. '
                       'Please add and verify a bank account in your payout settings first.'
        }), 400

    data = request.get_json() or {}
    requested_amount = data.get('amount')
    if requested_amount:
        try:
            requested_amount = Decimal(str(requested_amount))
            if requested_amount <= 0 or requested_amount > available:
                return jsonify({'message': 'Invalid withdrawal amount.'}), 400
        except Exception:
            return jsonify({'message': 'Invalid amount format.'}), 400
    else:
        requested_amount = available  # withdraw all

    import uuid as _uuid
    reference = f"PWD-{_uuid.uuid4().hex[:12].upper()}"

    from app.services.escrow.paystack_provider import paystack_transfer_to_vendor
    result = paystack_transfer_to_vendor(
        recipient_code=bank_acc.recipient_code,
        amount_ngn=float(requested_amount),
        reference=reference,
        reason="Siiqo partner withdrawal",
    )

    if not result.get("success"):
        return jsonify({
            'message': f"Withdrawal failed: {result.get('error_message', 'Unknown error.')}"
        }), 400

    # Record withdrawal
    transfer_code = result.get("transfer_code", "")
    new_withdrawal = PartnerWithdrawal(
        partner_id=int(partner_id),
        amount=requested_amount,
        fee_amount=Decimal('0'),
        net_amount=requested_amount,
        status='PENDING',
        bank_account_id=bank_acc.id,
        transfer_code=transfer_code,
        transfer_reference=reference,
    )
    db.session.add(new_withdrawal)
    db.session.commit()

    return jsonify({
        'status': 'success',
        'message': 'Withdrawal initiated. Funds will arrive within 24 hours.',
        'transfer_code': transfer_code,
        'amount': str(requested_amount),
    }), 200



# ---------------------------------------------------------------------------
# DAYA-NATIVE BANK ACCOUNT REGISTRATION
# Separate from Paystack path — fetches banks and verifies accounts via Daya.
# Bank codes stored here are CBN codes that work directly with Daya transfers.
# ---------------------------------------------------------------------------

@withdrawal_bp.route('/daya-banks', methods=['GET'])
def get_daya_banks():
    """
    Return Nigerian banks from Daya's bank list.
    These use CBN bank codes (not Paystack internal codes) so they work
    directly with Daya /v1/transfers without any translation.
    Public endpoint — no auth required.
    """
    from app.services import daya_service
    try:
        data = daya_service._request(
            "GET",
            "/v1/banks",
            headers=daya_service._headers(),
        )
        banks = data.get("data", [])
        formatted = sorted(
            [{"name": b["name"], "code": b["code"]} for b in banks if b.get("code") and b.get("name")],
            key=lambda x: x["name"],
        )
        return jsonify({"status": "success", "banks": formatted}), 200
    except Exception as exc:
        logging.warning("[DAYA BANKS] Failed to fetch: %s — falling back to empty list", exc)
        return jsonify({"status": "success", "banks": []}), 200


@withdrawal_bp.route('/daya-bank-account', methods=['POST'])
@jwt_required()
def add_daya_bank_account():
    """
    Register a vendor payout bank account using Daya's verification.
    Bank codes are Daya/CBN-native — no Paystack involved.

    Used for Daya-path payouts (NGN onramp + crypto orders).
    Completely separate from Paystack bank account registration.

    Body: { bank_code, account_number, bank_name }
    """
    from app.services import daya_service

    vendor_id = int(get_jwt_identity())
    data = request.get_json() or {}

    bank_code = (data.get("bank_code") or "").strip()
    account_number = (data.get("account_number") or "").strip()
    bank_name = (data.get("bank_name") or "").strip()

    if not bank_code or not account_number:
        return jsonify({"message": "bank_code and account_number are required"}), 400

    if len(account_number) != 10 or not account_number.isdigit():
        return jsonify({"message": "Account number must be exactly 10 digits"}), 400

    # Step 1: Verify account via Daya's resolve endpoint
    account_name = ""
    try:
        resolved = daya_service.resolve_bank_account(bank_code, account_number)
        account_name = resolved.get("account_name", "")
    except RuntimeError as exc:
        logging.warning(
            "[DAYA BANK REG] Could not verify account %s/%s via Daya: %s — saving without name",
            bank_code, account_number, exc
        )
        # Not a hard failure — Daya resolve is best-effort.
        # Transfer still includes account_name if we have it, which bypasses
        # Daya's internal resolution on payout anyway.

    # Step 2: Create Paystack transfer recipient (translates CBN code -> Paystack code)
    recipient_code = None
    try:
        from app.services.escrow.paystack_provider import ensure_paystack_transfer_recipient
        rec_res = ensure_paystack_transfer_recipient(
            account_number=account_number,
            bank_code=bank_code,
            account_name=account_name or bank_name,
        )
        if rec_res.get("success"):
            recipient_code = rec_res.get("recipient_code")
            if not account_name and rec_res.get("account_name"):
                account_name = rec_res["account_name"]
            logging.info("[DAYA BANK REG] Paystack recipient created: %s", recipient_code)
    except Exception as _rec_err:
        logging.warning("[DAYA BANK REG] Could not create Paystack recipient: %s", _rec_err)

    # Step 3: Check for duplicate (same account_number for this vendor)
    existing = VendorBankAccount.query.filter_by(
        vendor_id=vendor_id,
        account_number=account_number,
    ).first()
    if existing:
        # If existing is missing recipient_code or details, update it
        if recipient_code and not existing.recipient_code:
            existing.recipient_code = recipient_code
        if bank_code:
            existing.bank_code = bank_code
        if bank_name:
            existing.bank_name = bank_name
        if account_name:
            existing.account_name = account_name
        db.session.commit()
        return jsonify({"status": "success", "message": "Bank account updated successfully", "account": existing.to_dict()}), 200

    # Step 4: Save with Daya-native bank code and Paystack recipient_code
    is_first = VendorBankAccount.query.filter_by(vendor_id=vendor_id).count() == 0

    bank_account = VendorBankAccount(
        vendor_id=vendor_id,
        bank_name=bank_name,
        bank_code=bank_code,           # CBN/Daya code — works on Daya transfers
        account_number=account_number,
        account_name=account_name,
        recipient_code=recipient_code, # Paystack recipient — works on Paystack transfers
        is_verified=bool(account_name),
        verified_at=_utcnow() if account_name else None,
        is_default=is_first,
    )
    db.session.add(bank_account)

    # Step 4: Optionally create Paystack subaccount for split payments
    # (This is best-effort — if it fails, Daya payout still works fine)
    try:
        from app.services.escrow.paystack_provider import create_paystack_subaccount
        from app.models.user import Storefront
        storefront = Storefront.query.filter_by(vendor_id=vendor_id).first()
        business_name = storefront.store_name if storefront else (account_name or bank_name)
        # Use Paystack's bank code if different from Daya's
        # For standard banks they're the same; for mobile money they differ.
        # We attempt with the Daya code — Paystack will accept most standard codes.
        sub_result = create_paystack_subaccount(
            business_name=business_name,
            bank_code=bank_code,
            account_number=account_number,
        )
        if sub_result.get("success"):
            bank_account.paystack_subaccount_code = sub_result["subaccount_code"]
            if storefront:
                storefront.paystack_subaccount_code = sub_result["subaccount_code"]
            logging.info("[DAYA BANK REG] Paystack subaccount %s created for vendor %s",
                         sub_result["subaccount_code"], vendor_id)
        else:
            logging.warning("[DAYA BANK REG] Paystack subaccount failed for vendor %s: %s",
                            vendor_id, sub_result.get("error_message"))
    except Exception as exc:
        logging.warning("[DAYA BANK REG] Paystack subaccount error for vendor %s: %s", vendor_id, exc)

    db.session.commit()

    logging.info("[DAYA BANK REG] Vendor %s registered Daya bank: %s %s (%s)",
                 vendor_id, bank_name, account_number[-4:], bank_code)

    # Auto-retry any pending stalled payouts for this vendor now that bank account is added
    try:
        from app.models.order import Order
        from app.routes.payments import _payout_vendor_via_daya

        # Find all orders where vendor had a stalled payout notification
        pending_payout_notifs = Notification.query.filter_by(
            user_id=vendor_id,
            title="Payout Pending — Add Bank Account",
        ).all()

        for notif in pending_payout_notifs:
            if not notif.order_id:
                continue
            # Check if this order was already successfully paid
            already_sent = Notification.query.filter_by(
                user_id=vendor_id,
                order_id=notif.order_id,
                title="Payment On Its Way",
            ).first()
            if already_sent:
                continue

            order_to_pay = db.session.get(Order, notif.order_id)
            if not order_to_pay or not order_to_pay.escrow:
                continue

            logging.info(
                "[DAYA RETRY] Auto-retrying stalled payout for Order #%s after bank account added by vendor %s",
                order_to_pay.id, vendor_id,
            )
            _payout_vendor_via_daya(order_to_pay, order_to_pay.escrow)
    except Exception as retry_err:
        logging.warning("[DAYA RETRY] Error auto-retrying stalled payouts: %s", retry_err)

    return jsonify({
        "status": "success",
        "message": "Bank account registered successfully" + (f" — verified as {account_name}" if account_name else ""),
        "account": bank_account.to_dict(),
    }), 201
