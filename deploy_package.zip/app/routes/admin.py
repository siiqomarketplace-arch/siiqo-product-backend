import logging
import time
"""
admin.py — Admin panel routes
All routes require a valid AdminUser JWT.
SUPERADMIN role required for destructive/sensitive operations.

Security Features:
- Rate limiting on all endpoints
- Brute force protection on login
- IP whitelisting for admin panel
- Audit logging for all actions
- Anomaly detection on sensitive routes
"""
from datetime import datetime, timezone

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, create_access_token

from app.extensions import db
from app.models.admin import AdminUser, PlatformSetting, SubscriptionPlan, VendorSubscription
from app.models.user import User, Storefront
from app.models.escrow import EscrowTransaction, EscrowStatus
from app.models.community import Article, BlogAuthor, ArticleSlugRedirect
from app.models.product import Category
from app.models.partnerships import PartnerApplication
from app.models.finance import Ledger
from app.models.communication import Notification
from app.models.audit import AdminAuditLog
from app.utils.email import send_siiqo_email
from app.middleware.security import (
    limiter, 
    brute_force, 
    require_admin_whitelist,
    detect_anomalies,
)

admin_bp = Blueprint('admin', __name__)


def _utcnow():
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_admin(admin_id) -> "AdminUser | None":
    try:
        return db.session.get(AdminUser, int(admin_id))
    except (ValueError, TypeError):
        return None


def _require_superadmin(admin_id) -> AdminUser | None:
    admin = _get_admin(admin_id)
    if not admin or admin.role != 'SUPERADMIN':
        return None
    return admin


def _credit_vendor_ledger(vendor_id: int, amount: float, reference_id: str, description: str):
    from sqlalchemy import func
    credits = db.session.query(func.sum(Ledger.amount)).filter_by(
        vendor_id=vendor_id, transaction_type='CREDIT'
    ).scalar() or 0
    debits = db.session.query(func.sum(Ledger.amount)).filter_by(
        vendor_id=vendor_id, transaction_type='DEBIT'
    ).scalar() or 0
    balance_after = float(credits) - float(debits) + amount
    db.session.add(Ledger(
        vendor_id=vendor_id,
        transaction_type='CREDIT',
        amount=amount,
        description=description,
        reference_id=reference_id,
        balance_after=balance_after,
    ))


# ---------------------------------------------------------------------------
# POST /admin/login — WITH BRUTE FORCE PROTECTION
# ---------------------------------------------------------------------------

@admin_bp.route('/login', methods=['POST'])
@limiter.limit("10 per minute")  # Rate limit: 10 attempts per minute per IP
@require_admin_whitelist  # Only allow whitelisted IPs
@detect_anomalies  # Check for injection attacks
def admin_login():
    """
    Admin login with enterprise-grade security:
    - Rate limiting (10 attempts/min per IP)
    - IP whitelisting (requires ADMIN_IP_WHITELIST env var)
    - Brute force protection (5 failures = 15 min lockout)
    - Progressive delays after failed attempts
    - Audit logging
    - Anomaly detection (SQL injection, XSS)
    """
    try:
        from app.extensions import get_real_client_ip
        ip = get_real_client_ip()
    except Exception:
        from flask_limiter.util import get_remote_address
        ip = get_remote_address()
    
    # Check if IP is currently blocked
    is_blocked, block_reason = brute_force.is_blocked(ip)
    if is_blocked:
        logging.warning(f"[SECURITY] Blocked login attempt from {ip}: {block_reason}")
        return jsonify({"message": block_reason, "error": "RATE_LIMIT_EXCEEDED"}), 429
    
    data = request.get_json() or {}
    email = (data.get('email') or '').strip().lower()
    password = data.get('password', '')

    if not email or not password:
        return jsonify({"message": "Email and password required"}), 400

    # Progressive delay based on previous failed attempts
    delay = brute_force.get_delay(ip)
    if delay > 0:
        logging.info(f"[SECURITY] Applying {delay}s delay to {ip} due to previous failures")
        time.sleep(delay)

    admin = AdminUser.query.filter_by(email=email).first()
    
    # Constant-time comparison to prevent timing attacks
    valid_admin = admin is not None
    valid_password = admin.check_password(password) if admin else False
    
    if not (valid_admin and valid_password):
        # Record failed attempt
        brute_force.record_failure(ip, email)
        logging.warning(f"[SECURITY] Failed admin login attempt: {email} from {ip}")
        
        # Generic error message (don't reveal if email exists)
        return jsonify({"message": "Invalid credentials"}), 401

    if not admin.is_active:
        logging.warning(f"[SECURITY] Suspended admin attempted login: {email} from {ip}")
        return jsonify({"message": "Account suspended"}), 403

    # Success - clear failed attempts
    brute_force.record_success(ip)
    
    admin.last_login = _utcnow()
    db.session.commit()
    
    # Audit log successful login
    AdminAuditLog.log_action(
        admin=admin,
        action='ADMIN_LOGIN',
        resource_type='AdminUser',
        resource_id=admin.id,
        details={'success': True},
        ip_address=ip,
    )
    
    logging.info(f"[SECURITY] Successful admin login: {email} from {ip}")

    # Use a prefixed identity to distinguish admin tokens from user tokens
    access_token = create_access_token(identity=f"admin:{admin.id}")

    return jsonify({
        "status": "success",
        "access_token": access_token,
        "admin": {
            "id": admin.id,
            "name": admin.name,
            "email": admin.email,
            "role": admin.role,
        },
    }), 200


# ---------------------------------------------------------------------------
# GET /admin/stats
# ---------------------------------------------------------------------------

@admin_bp.route('/stats', methods=['GET'])
@jwt_required()
def admin_dashboard():
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    from app.models.order import Order
    from sqlalchemy import func

    total_users = User.query.count()
    total_vendors = User.query.filter_by(role='VENDOR').count()
    total_storefronts = Storefront.query.count()
    live_storefronts = Storefront.query.filter_by(is_verified=True, is_published=True).count()
    pending_vendors = Storefront.query.filter_by(is_verified=False).count()
    total_orders = Order.query.count()
    total_escrow = EscrowTransaction.query.count()
    pending_escrow = EscrowTransaction.query.filter_by(status=EscrowStatus.PENDING_PAYMENT).count()
    disputed_escrow = EscrowTransaction.query.filter_by(status=EscrowStatus.DISPUTED).count()

    total_gmv = db.session.query(func.sum(Order.total_amount)).filter_by(status='COMPLETED').scalar() or 0
    total_fees = db.session.query(func.sum(EscrowTransaction.fee_amount)).filter_by(
        status=EscrowStatus.RELEASED
    ).scalar() or 0

    return jsonify({
        "total_users": total_users,
        "total_vendors": total_vendors,
        "total_storefronts": total_storefronts,
        "live_storefronts": live_storefronts,
        "pending_vendor_approvals": pending_vendors,
        "total_orders": total_orders,
        "total_escrow_transactions": total_escrow,
        "pending_escrow": pending_escrow,
        "disputed_escrow": disputed_escrow,
        "total_gmv": str(total_gmv),
        "total_platform_fees": str(total_fees),
    }), 200


def _parse_admin_id(identity: str) -> int:
    """Extract numeric ID from 'admin:123' or plain '123'. Returns -1 on bad input (will fail auth check)."""
    try:
        if isinstance(identity, str) and identity.startswith('admin:'):
            return int(identity.split(':', 1)[1])
        return int(identity)
    except (ValueError, TypeError):
        return -1


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

@admin_bp.route('/users/all', methods=['GET'])
@jwt_required()
def get_all_users():
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    users = User.query.order_by(User.created_at.desc()).limit(500).all()
    user_list = []
    for u in users:
        if not u.is_active:
            status = 'suspended'
        elif u.storefront and u.storefront.verification_status == 'PENDING_VERIFY_SUB':
            status = 'pending'
        elif u.storefront and u.storefront.verification_status == 'VERIFIED':
            status = 'verified'
        elif u.is_active and u.is_verified:
            status = 'verified'
        else:
            status = 'unverified'

        sf = u.storefront
        user_list.append({
            "id": u.id,
            "email": u.email,
            "name": u.full_name,
            "phone": u.phone,
            "role": u.role,
            "is_verified": u.is_verified,
            "is_active": u.is_active,
            "status": status,
            "joined_at": u.created_at.isoformat() if u.created_at else None,
            "has_storefront": sf is not None,
            # KYC / Verification fields
            "nin": u.nin,
            "cac_reg": sf.cac_reg if sf else None,
            "account_type": sf.account_type if sf else None,
            "verification_status": sf.verification_status if sf else None,
            "nin_document_url": sf.nin_document_url if sf else None,
            "cac_document_url": sf.cac_document_url if sf else None,
            # Storefront basics
            "store_name": sf.store_name if sf else None,
            "store_logo": sf.store_logo if sf else None,
            "store_slug": sf.store_slug if sf else None,
            "market_presence": {
                "storefront_link": sf.store_slug if sf else None,
                "is_published": sf.is_published if sf else False,
                "product_count": len(sf.products) if sf and sf.products else 0,
                "website": sf.website if sf else None,
            } if sf else None,
        })

    return jsonify({"users": user_list, "count": len(user_list)}), 200


@admin_bp.route('/users/<int:user_id>', methods=['GET'])
@jwt_required()
def get_user_detail(user_id):
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    user = db.session.get(User, user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    from app.models.order import Order
    from app.models.partnerships import Referral
    
    orders = Order.query.filter(
        (Order.buyer_id == user.id) | (Order.vendor_id == user.id)
    ).count()

    referrals_query = Referral.query.filter_by(referrer_id=user.id).all()
    referrals_list = [{
        "referred_user_email": r.referred.email if r.referred else "Unknown",
        "referred_user_name": r.referred.full_name if r.referred else "Unknown",
        "status": r.status,
        "created_at": r.created_at.strftime('%Y-%m-%d %H:%M:%S') if r.created_at else "Unknown"
    } for r in referrals_query]

    return jsonify({
        "user": {
            **user.to_public_dict(),
            "total_orders": orders,
            "storefront": user.storefront.to_public_dict() if user.storefront else None,
            "referrals_made": referrals_list,
        }
    }), 200


@admin_bp.route('/users/<int:user_id>/status', methods=['PATCH'])
@jwt_required()
@limiter.limit("30 per minute")
@detect_anomalies
def update_user_status(user_id):
    """
    Update user/vendor status with audit logging.
    Security: Rate limited, anomaly detected, audit logged.
    """
    admin_id = get_jwt_identity()
    admin = _require_superadmin(_parse_admin_id(admin_id))
    if not admin:
        return jsonify({"message": "SuperAdmin required"}), 403

    user = db.session.get(User, user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    data = request.get_json() or {}
    status = data.get('status', '').strip().lower()
    
    # Whitelist allowed status values to prevent mass assignment
    ALLOWED_STATUSES = {'active', 'verified', 'approved', 'kyc_approved', 'suspended', 'rejected', 'unverified'}
    if status not in ALLOWED_STATUSES:
        return jsonify({"message": f"Invalid status. Allowed: {ALLOWED_STATUSES}"}), 400
    
    # Store old values for audit
    old_values = {
        'is_verified': user.is_verified,
        'is_active': user.is_active,
        'verification_status': user.storefront.verification_status if user.storefront else None,
    }

    if status in ('active', 'verified', 'approved'):
        # Stage 1: Admin approves vendor to go public. Does NOT grant the Verified badge.
        user.is_verified = True
        user.is_active = True
        if user.storefront:
            user.storefront.is_verified = True
            # verification_status is intentionally NOT changed here.
            # The Verified badge is granted separately via 'kyc_approved'.
            try:
                send_siiqo_email(
                    to_email=user.email,
                    subject="Congratulations! Your Siiqo Store is Approved",
                    template_name="vendor_approved",
                    first_name=user.first_name or "Vendor",
                    store_name=user.storefront.store_name,
                )
            except Exception:
                pass

    elif status == 'kyc_approved':
        # Stage 2: Admin approves submitted KYC (NIN/CAC). Grants the Verified badge.
        # Also grants Pro Verified (is_pro_verified) at no charge — grandfathering
        # vendors who verified before the paid Pro Verified system was introduced.
        user.is_verified = True
        user.is_active = True
        if user.storefront:
            user.storefront.is_verified = True
            user.storefront.verification_status = 'VERIFIED'
            # Grandfather: give them Pro Verified badge for free (1 year)
            from datetime import timedelta as _td
            from datetime import datetime as _dt_kyc
            user.storefront.is_pro_verified = True
            user.storefront.pro_verified_expires_at = _dt_kyc.utcnow() + _td(days=365)
            try:
                send_siiqo_email(
                    to_email=user.email,
                    subject="Your Identity is Verified — Siiqo",
                    template_name="vendor_approved",
                    first_name=user.first_name or "Vendor",
                    store_name=user.storefront.store_name,
                )
            except Exception:
                pass
    elif status == 'suspended':
        user.is_active = False
        if user.storefront:
            try:
                send_siiqo_email(
                    to_email=user.email,
                    subject="Important: Your Siiqo Storefront has been suspended",
                    template_name="vendor_suspended",
                    first_name=user.first_name or "Vendor",
                    store_name=user.storefront.store_name,
                )
            except Exception:
                pass
    elif status == 'rejected':
        if user.storefront:
            user.storefront.verification_status = 'REJECTED'
            user.storefront.is_verified = False
            try:
                send_siiqo_email(
                    to_email=user.email,
                    subject="Verification Update: Siiqo Application Status",
                    template_name="vendor_verification_rejected",
                    first_name=user.first_name or "Vendor",
                    store_name=user.storefront.store_name,
                )
            except Exception:
                pass
    elif status == 'unverified':
        user.is_verified = False
        if user.storefront:
            user.storefront.verification_status = 'NOT_SUBMITTED'

    db.session.commit()

    # Recalculate trust score for storefront verification changes
    try:
        from app.services.trust import recalculate_vendor_trust
        if user.role == 'VENDOR':
            recalculate_vendor_trust(user.id, reason="Admin Verification Update")
    except Exception as e:
        logging.error(f"[TRUST ERROR] Failed to recalculate trust on user status update: {e}")
    
    # Audit log the status change
    AdminAuditLog.log_action(
        admin=admin,
        action='USER_STATUS_UPDATE',
        resource_type='User',
        resource_id=user.id,
        details={
            'user_email': user.email,
            'new_status': status,
            'old_values': old_values,
            'new_values': {
                'is_verified': user.is_verified,
                'is_active': user.is_active,
                'verification_status': user.storefront.verification_status if user.storefront else None,
            }
        }
    )
    
    logging.info(f"[ADMIN] User {user.email} status updated to {status} by {admin.email}")

    return jsonify({"message": f"User {user.email} status updated to {status}."}), 200


@admin_bp.route('/users/<int:user_id>', methods=['DELETE'])
@jwt_required()
@limiter.limit("10 per hour")  # Strict rate limit on destructive operations
@detect_anomalies
def delete_user_admin(user_id):
    """
    Delete user and all associated data.
    Security: Strict rate limiting, anomaly detection, comprehensive audit logging.
    """
    admin_id = get_jwt_identity()
    admin = _require_superadmin(_parse_admin_id(admin_id))
    if not admin:
        return jsonify({"message": "SuperAdmin required"}), 403

    user = db.session.get(User, user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    try:
        from app.models.escrow import EscrowTransaction as ET
        from app.models.order import Order, OrderItem
        from app.models.trust import VendorTrustProfile, TrustScoreHistory
        from app.models.withdrawal import VendorBankAccount, Withdrawal, PODPayment, VendorCryptoWallet, DayaPayment
        from app.models.payment_link import PaymentLink
        from app.models.social import Post, PostLike, PostComment, Follow, PostView, UserActivity
        from app.models.communication import Notification, Message
        from app.models.finance import Invoice, Receipt, Ledger
        from app.models.admin import VendorSubscription, SponsoredListing, Favorite
        from app.models.partnerships import PartnerApplication, Referral, PartnerStaff
        from app.models.community import Review

        uid = user.id

        # ── 1. Trust ──────────────────────────────────────────────────
        TrustScoreHistory.query.filter_by(vendor_id=uid).delete(synchronize_session=False)
        VendorTrustProfile.query.filter_by(vendor_id=uid).delete(synchronize_session=False)

        # ── 2. Social ─────────────────────────────────────────────────
        UserActivity.query.filter_by(user_id=uid).delete(synchronize_session=False)
        Follow.query.filter(
            (Follow.follower_id == uid) | (Follow.following_id == uid)
        ).delete(synchronize_session=False)
        PostView.query.filter_by(user_id=uid).delete(synchronize_session=False)
        PostLike.query.filter_by(user_id=uid).delete(synchronize_session=False)
        PostComment.query.filter_by(user_id=uid).delete(synchronize_session=False)
        Post.query.filter_by(user_id=uid).delete(synchronize_session=False)

        # ── 3. Notifications & Messages ───────────────────────────────
        Notification.query.filter_by(user_id=uid).delete(synchronize_session=False)
        Message.query.filter(
            (Message.sender_id == uid) | (Message.receiver_id == uid)
        ).delete(synchronize_session=False)

        # ── 4. Reviews ────────────────────────────────────────────────
        Review.query.filter(
            (Review.vendor_id == uid) | (Review.buyer_id == uid)
        ).delete(synchronize_session=False)

        # ── 5. Finance ────────────────────────────────────────────────
        Invoice.query.filter_by(vendor_id=uid).delete(synchronize_session=False)
        Receipt.query.filter_by(vendor_id=uid).delete(synchronize_session=False)
        Ledger.query.filter_by(vendor_id=uid).delete(synchronize_session=False)

        # ── 6. Payment links ──────────────────────────────────────────
        PaymentLink.query.filter_by(vendor_id=uid).delete(synchronize_session=False)

        # ── 7. Withdrawals & bank accounts ────────────────────────────
        Withdrawal.query.filter_by(vendor_id=uid).delete(synchronize_session=False)
        VendorBankAccount.query.filter_by(vendor_id=uid).delete(synchronize_session=False)
        VendorCryptoWallet.query.filter_by(vendor_id=uid).delete(synchronize_session=False)
        DayaPayment.query.filter_by(buyer_id=uid).delete(synchronize_session=False)

        # ── 8. Subscriptions & sponsored listings & favorites ─────────
        VendorSubscription.query.filter_by(vendor_id=uid).delete(synchronize_session=False)
        SponsoredListing.query.filter_by(vendor_id=uid).delete(synchronize_session=False)
        Favorite.query.filter_by(user_id=uid).delete(synchronize_session=False)

        # ── 9. Partnerships & referrals ───────────────────────────────
        Referral.query.filter(
            (Referral.referrer_id == uid) | (Referral.referred_id == uid)
        ).delete(synchronize_session=False)
        PartnerStaff.query.filter_by(partner_id=uid).delete(synchronize_session=False)
        PartnerApplication.query.filter_by(user_id=uid).delete(synchronize_session=False)

        # ── 10. Orders & escrow ───────────────────────────────────────
        orders = Order.query.filter(
            (Order.buyer_id == uid) | (Order.vendor_id == uid)
        ).all()
        for order in orders:
            ET.query.filter_by(order_id=order.id).delete(synchronize_session=False)
            OrderItem.query.filter_by(order_id=order.id).delete(synchronize_session=False)
            db.session.delete(order)

        # ── 11. Products & storefront ─────────────────────────────────
        if user.storefront:
            from app.models.product import Product
            Product.query.filter_by(storefront_id=user.storefront.id).delete(synchronize_session=False)
            db.session.delete(user.storefront)

        # ── 12. Delete user ───────────────────────────────────────────
        user_email = user.email  # Store before deletion
        user_data_summary = {
            'email': user.email,
            'role': user.role,
            'storefront_id': user.storefront.id if user.storefront else None,
            'storefront_name': user.storefront.store_name if user.storefront else None,
        }
        
        db.session.delete(user)
        db.session.commit()
        
        # Audit log the deletion
        AdminAuditLog.log_action(
            admin=admin,
            action='USER_DELETE',
            resource_type='User',
            resource_id=user_id,
            details=user_data_summary
        )
        
        logging.warning(f"[ADMIN CRITICAL] User {user_email} DELETED by {admin.email}")
        
        return jsonify({"message": f"User {user_email} and all data deleted."}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Failed to delete user: {str(e)}"}), 500


# ---------------------------------------------------------------------------
# Storefronts
# ---------------------------------------------------------------------------

@admin_bp.route('/storefronts', methods=['GET'])
@jwt_required()
def get_all_storefronts():
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    status = request.args.get('status')
    query = Storefront.query
    if status:
        query = query.filter_by(verification_status=status)

    storefronts = query.order_by(Storefront.created_at.desc()).limit(500).all()
    return jsonify({
        "storefronts": [{
            "id": s.id,
            "business_name": s.store_name,
            "store_slug": s.store_slug,
            "vendor_name": s.vendor.full_name if s.vendor else "Unknown",
            "vendor_email": s.vendor.email if s.vendor else "",
            "phone": s.phone or (s.vendor.phone if s.vendor else None),
            "is_verified": s.is_verified,
            "is_published": s.is_published,
            "is_live": s.is_live,
            "vendor_status": "Approved" if s.is_verified else "Pending",
            "city": s.city,
            "state": s.state,
            "created_at": s.created_at.isoformat() if s.created_at else None,
            # verification details
            "account_type": s.account_type,
            "cac_reg": s.cac_reg,
            "nin": s.vendor.nin if s.vendor else None,
            "nin_document_url": s.nin_document_url,
            "cac_document_url": s.cac_document_url,
            "verification_status": s.verification_status,
        } for s in storefronts],
        "count": len(storefronts),
    }), 200


# ---------------------------------------------------------------------------
# Categories
# ---------------------------------------------------------------------------

@admin_bp.route('/categories', methods=['GET', 'POST'])
@jwt_required()
def handle_categories():
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    if request.method == 'GET':
        cats = Category.query.limit(500).all()
        return jsonify({
            "categories": [{
                "id": c.id,
                "name": c.name,
                "slug": c.slug,
                "icon": c.icon,
                "attribute_schema": c.attribute_schema or [],
                "product_type_hint": c.product_type_hint or [],
            } for c in cats],
            "count": len(cats),
        }), 200

    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    data = request.get_json() or {}
    name = (data.get('name') or '').strip()
    if not name:
        return jsonify({"message": "Category name is required"}), 400

    import re
    slug = data.get('slug') or re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')

    if Category.query.filter_by(slug=slug).first():
        return jsonify({"message": "Category already exists"}), 409

    cat = Category(
        name=name,
        slug=slug,
        icon=data.get('icon'),
        attribute_schema=data.get('attribute_schema'),
        product_type_hint=data.get('product_type_hint'),
    )
    db.session.add(cat)
    db.session.commit()
    return jsonify({"message": f"Category '{name}' created.", "id": cat.id, "slug": cat.slug}), 201


@admin_bp.route('/categories/<int:cat_id>', methods=['PATCH', 'DELETE'])
@jwt_required()
def manage_category(cat_id):
    admin_id = get_jwt_identity()
    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    cat = db.session.get(Category, cat_id)
    if not cat:
        return jsonify({"message": "Category not found"}), 404

    if request.method == 'DELETE':
        from app.models.product import Product as Prod
        product_count = Prod.query.filter_by(category_id=cat_id).count()
        force = request.args.get('force', 'false').lower() == 'true'
        if product_count > 0 and not force:
            return jsonify({
                "message": f"Cannot delete '{cat.name}'. It has {product_count} product(s) assigned. "
                           f"Pass ?force=true to delete anyway (products will become uncategorized).",
                "product_count": product_count,
                "requires_force": True,
            }), 409
        if product_count > 0 and force:
            Prod.query.filter_by(category_id=cat_id).update({"category_id": None})
        db.session.delete(cat)
        db.session.commit()
        return jsonify({"message": f"Category '{cat.name}' deleted.", "affected_products": product_count}), 200

    data = request.get_json() or {}
    if 'name' in data:
        cat.name = data['name']
    if 'slug' in data:
        cat.slug = data['slug']
    # New enrichment fields — safe to update independently
    if 'icon' in data:
        cat.icon = data['icon']
    if 'attribute_schema' in data:
        cat.attribute_schema = data['attribute_schema']
    if 'product_type_hint' in data:
        cat.product_type_hint = data['product_type_hint']
    db.session.commit()
    return jsonify({"message": "Category updated.", "id": cat.id}), 200


# ---------------------------------------------------------------------------
# Escrow Management
# ---------------------------------------------------------------------------

@admin_bp.route('/escrow/pending', methods=['GET'])
@jwt_required()
def get_pending_escrow():
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    from app.models.order import Order, OrderItem

    # Bug fix: exclude PENDING_PAYMENT (abandoned/unpaid checkouts) — only show
    # funded escrows and active disputes in the admin Escrow & Disputes panel.
    pending = EscrowTransaction.query.filter(
        EscrowTransaction.status.in_([
            EscrowStatus.IN_ESCROW,
            EscrowStatus.DISPUTED,
        ])
    ).order_by(EscrowTransaction.created_at.desc()).limit(500).all()

    result = []
    for e in pending:
        order = e.order
        buyer = db.session.get(User, order.buyer_id) if (order and order.buyer_id) else None
        vendor = db.session.get(User, order.vendor_id) if order else None
        vendor_store = vendor.storefront if vendor else None

        items = []
        if order:
            for item in order.items:
                items.append({
                    "name": item.product.name if item.product else "Unknown Product",
                    "quantity": item.quantity,
                    "price": float(item.price_at_purchase),
                })

        # Bug fix: fall back to order.buyer_name / order.buyer_email for guest checkouts
        # (buyer_id is null for guests, so buyer User object is None)
        resolved_buyer_name  = (buyer.full_name  if buyer else None) or (order.buyer_name  if order else None) or "Guest Buyer"
        resolved_buyer_email = (buyer.email      if buyer else None) or (order.buyer_email if order else None) or ""

        result.append({
            **e.to_dict(),
            # Richer fields for dispute resolution
            "order_id": order.id if order else None,
            "order_status": order.status if order else None,
            "order_created_at": order.created_at.isoformat() if order and order.created_at else None,
            "payment_method": order.payment_method if order else None,
            # Buyer
            "buyer_id": buyer.id if buyer else None,
            "buyer_name": resolved_buyer_name,
            "buyer_email": resolved_buyer_email,
            # Vendor
            "vendor_id": vendor.id if vendor else None,
            "vendor_name": vendor_store.store_name if vendor_store else (vendor.full_name if vendor else "Unknown"),
            "vendor_email": vendor.email if vendor else "",
            # Items
            "items": items,
            "total_amount": float(e.amount),
        })

    return jsonify({
        "pending_escrow": result,
        "count": len(result),
    }), 200


@admin_bp.route('/escrow/transactions', methods=['GET'])
@jwt_required()
def get_all_escrow_transactions():
    """
    Returns ALL escrow transactions for the admin escrow dashboard.
    Normalises data into the shape the frontend AdminEscrowDashboard expects:
      { id, vendor_id, buyer_id, product, total_amount, platform_fee,
        status ("held" | "disputed" | "released" | "refunded"),
        created_at, auto_release_date, logistics_provider }
    """
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    from app.models.order import Order, OrderItem
    from app.models.product import Product
    from datetime import timedelta

    # Status map: backend canonical → frontend display key
    STATUS_MAP = {
        EscrowStatus.PENDING_PAYMENT: "pending_payment",
        EscrowStatus.IN_ESCROW:       "held",
        EscrowStatus.SHIPPED:         "held",
        EscrowStatus.DELIVERED:       "held",
        EscrowStatus.RELEASED:        "released",
        EscrowStatus.DISPUTED:        "disputed",
        EscrowStatus.REFUNDED:        "refunded",
        EscrowStatus.CANCELLED:       "refunded",
    }

    include_unpaid = request.args.get("include_unpaid", "false").lower() == "true"
    query = EscrowTransaction.query
    if not include_unpaid:
        # Exclude unpaid draft checkouts so admin escrow dashboard only shows orders with funded escrow
        query = query.filter(EscrowTransaction.status != EscrowStatus.PENDING_PAYMENT)

    transactions = query.order_by(
        EscrowTransaction.created_at.desc()
    ).limit(1000).all()

    result = []
    for txn in transactions:
        order = txn.order
        if not order:
            continue

        # Derive a human-readable product name from first order item
        first_item = order.items[0] if order.items else None
        product_name = (
            first_item.product.name if first_item and first_item.product
            else f"Order #{order.id}"
        )

        # Auto-release date = updated_at + 72 h when status is DELIVERED
        auto_release_date = None
        if txn.status == EscrowStatus.DELIVERED and txn.updated_at:
            auto_release_date = (txn.updated_at + timedelta(hours=72)).isoformat()

        result.append({
            "id": txn.transaction_number,
            "order_id": order.id,
            "vendor_id": str(order.vendor_id),
            "buyer_id": str(order.buyer_id) if order.buyer_id else "guest",
            # Prefer registered buyer account; fall back to guest-checkout fields
            "buyer_name": (
                order.buyer.full_name if order.buyer else None
            ) or order.buyer_name or "Guest Buyer",
            "buyer_email": (
                order.buyer.email if order.buyer else None
            ) or order.buyer_email or "",
            "buyer_phone": (
                order.buyer.phone if order.buyer else None
            ) or order.delivery_phone or "",
            "is_guest": bool(order.is_guest or not order.buyer_id),
            "product": product_name,
            "total_amount": float(txn.amount),
            "platform_fee": float(txn.fee_amount or 0),
            "status": STATUS_MAP.get(txn.status, "held"),
            "escrow_status": txn.status,   # raw backend status for admin detail
            "created_at": txn.created_at.isoformat() if txn.created_at else None,
            "auto_release_date": auto_release_date,
            "logistics_provider": order.logistics_provider_id or "Standard Delivery",
            "dispute_id": txn.dispute_id,
            "dispute_reason": txn.dispute_reason,
        })

    return jsonify({"data": result, "count": len(result)}), 200


# ---------------------------------------------------------------------------
# Admin Orders Management
# ---------------------------------------------------------------------------

def _extract_product_image(product):
    """Safely extract product image URL whether images is list of strings, dicts, or objects."""
    if not product:
        return None
    images = getattr(product, 'images', None)
    if not images or not isinstance(images, (list, tuple)) or len(images) == 0:
        return None
    first = images[0]
    if isinstance(first, str):
        return first
    if isinstance(first, dict):
        return first.get('image_url') or first.get('url') or None
    return getattr(first, 'image_url', None) or getattr(first, 'url', None) or str(first)


@admin_bp.route('/orders', methods=['GET'])
@jwt_required()
def admin_get_orders():
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    from sqlalchemy import or_
    from app.models.order import Order
    from app.models.user import Storefront

    page = request.args.get('page', 1, type=int)
    per_page = min(request.args.get('per_page', 30, type=int), 100)
    status = (request.args.get('status') or '').strip().upper()
    payment_method = (request.args.get('payment_method') or '').strip().upper()
    search = (request.args.get('search') or '').strip()

    query = Order.query

    if status and status != 'ALL':
        query = query.filter(Order.status == status)

    if payment_method and payment_method != 'ALL':
        query = query.filter(Order.payment_method.ilike(f"%{payment_method}%"))

    if search:
        search_filter = []
        if search.isdigit():
            search_filter.append(Order.id == int(search))
        search_pattern = f"%{search}%"
        search_filter.append(Order.buyer_name.ilike(search_pattern))
        search_filter.append(Order.buyer_email.ilike(search_pattern))

        matching_vendor_ids = db.session.query(Storefront.vendor_id).filter(
            Storefront.store_name.ilike(search_pattern)
        ).subquery()
        search_filter.append(Order.vendor_id.in_(matching_vendor_ids))

        query = query.filter(or_(*search_filter))

    pagination = query.order_by(Order.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    orders_data = []
    for order in pagination.items:
        buyer = db.session.get(User, order.buyer_id) if order.buyer_id else None
        vendor = db.session.get(User, order.vendor_id) if order.vendor_id else None
        store = vendor.storefront if vendor else None

        items = []
        for itm in (order.items or []):
            items.append({
                "id": itm.id,
                "product_id": itm.product_id,
                "product_name": itm.product.name if itm.product else "Unknown Product",
                "quantity": itm.quantity,
                "price": float(itm.price_at_purchase or 0),
                "image": _extract_product_image(itm.product),
            })

        escrow = order.escrow
        escrow_data = {
            "status": escrow.status if escrow else None,
            "transaction_number": escrow.transaction_number if escrow else None,
            "fee_amount": float(escrow.fee_amount or 0) if escrow else 0.0,
            "released_at": escrow.released_at.isoformat() if (escrow and escrow.released_at) else None,
        } if escrow else None

        orders_data.append({
            "id": order.id,
            "order_number": f"#{order.id}",
            "status": order.status,
            "total_amount": float(order.total_amount or 0),
            "currency": "NGN",
            "payment_method": order.payment_method or "PAYSTACK",
            "created_at": order.created_at.isoformat() if order.created_at else None,
            "updated_at": order.updated_at.isoformat() if order.updated_at else None,
            "buyer": {
                "id": buyer.id if buyer else None,
                "name": (buyer.full_name if buyer else None) or order.buyer_name or "Guest Buyer",
                "email": (buyer.email if buyer else None) or order.buyer_email or "",
                "phone": (buyer.phone if buyer else None) or getattr(order, 'buyer_phone', None) or order.delivery_phone or "",
            },
            "vendor": {
                "id": vendor.id if vendor else None,
                "store_name": store.store_name if store else (vendor.full_name if vendor else "Unknown Vendor"),
                "email": vendor.email if vendor else "",
                "phone": vendor.phone if vendor else "",
            },
            "items_count": len(items),
            "items": items,
            "shipping_address": getattr(order, 'shipping_address', None),
            "escrow": escrow_data,
        })

    return jsonify({
        "status": "success",
        "orders": orders_data,
        "total": pagination.total,
        "pages": pagination.pages,
        "page": page,
        "per_page": per_page,
    }), 200


@admin_bp.route('/orders/<int:order_id>', methods=['GET'])
@jwt_required()
def admin_get_order_detail(order_id):
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    from app.models.order import Order
    from app.models.withdrawal import DayaPayment, VendorBankAccount

    order = db.session.get(Order, order_id)
    if not order:
        return jsonify({"message": "Order not found"}), 404

    buyer = db.session.get(User, order.buyer_id) if order.buyer_id else None
    vendor = db.session.get(User, order.vendor_id) if order.vendor_id else None
    store = vendor.storefront if vendor else None
    escrow = order.escrow

    daya_payment = DayaPayment.query.filter_by(order_id=order.id).first()
    vendor_bank = VendorBankAccount.query.filter_by(vendor_id=order.vendor_id, is_default=True).first() or \
                  VendorBankAccount.query.filter_by(vendor_id=order.vendor_id).first()

    items = []
    for itm in (order.items or []):
        items.append({
            "id": itm.id,
            "product_id": itm.product_id,
            "product_name": itm.product.name if itm.product else "Unknown Product",
            "quantity": itm.quantity,
            "price": float(itm.price_at_purchase or 0),
            "image": _extract_product_image(itm.product),
        })

    return jsonify({
        "status": "success",
        "order": {
            "id": order.id,
            "order_number": f"#{order.id}",
            "status": order.status,
            "total_amount": float(order.total_amount or 0),
            "payment_method": order.payment_method or "PAYSTACK",
            "created_at": order.created_at.isoformat() if order.created_at else None,
            "updated_at": order.updated_at.isoformat() if order.updated_at else None,
            "shipping_address": getattr(order, 'shipping_address', None),
            "buyer": {
                "id": buyer.id if buyer else None,
                "name": (buyer.full_name if buyer else None) or order.buyer_name or "Guest Buyer",
                "email": (buyer.email if buyer else None) or order.buyer_email or "",
                "phone": (buyer.phone if buyer else None) or getattr(order, 'buyer_phone', None) or order.delivery_phone or "",
            },
            "vendor": {
                "id": vendor.id if vendor else None,
                "store_name": store.store_name if store else (vendor.full_name if vendor else "Unknown Vendor"),
                "email": vendor.email if vendor else "",
                "phone": vendor.phone if vendor else "",
                "bank_name": vendor_bank.bank_name if vendor_bank else (store.bank_name if store else None),
                "account_number": vendor_bank.account_number if vendor_bank else (store.account_number if store else None),
                "account_name": vendor_bank.account_name if vendor_bank else (store.account_name if store else None),
            },
            "items": items,
            "escrow": {
                "status": escrow.status if escrow else None,
                "transaction_number": escrow.transaction_number if escrow else None,
                "fee_percent": float(escrow.fee_percent or 0) if escrow else 0.0,
                "fee_amount": float(escrow.fee_amount or 0) if escrow else 0.0,
                "released_at": escrow.released_at.isoformat() if (escrow and escrow.released_at) else None,
                "dispute_id": escrow.dispute_id if escrow else None,
                "dispute_reason": escrow.dispute_reason if escrow else None,
            } if escrow else None,
            "daya_payment": daya_payment.to_dict() if daya_payment else None,
        }
    }), 200


@admin_bp.route('/orders/<int:order_id>/status', methods=['PATCH'])
@jwt_required()
def admin_update_order_status(order_id):
    admin_id = get_jwt_identity()
    admin = _get_admin(_parse_admin_id(admin_id))
    if not admin:
        return jsonify({"message": "Unauthorized"}), 403

    from app.models.order import Order
    order = db.session.get(Order, order_id)
    if not order:
        return jsonify({"message": "Order not found"}), 404

    data = request.get_json() or {}
    new_status = (data.get('status') or '').strip().upper()
    valid_statuses = ['PENDING', 'CONFIRMED', 'SHIPPED', 'DELIVERED', 'COMPLETED', 'CANCELLED', 'DISPUTED']
    if new_status not in valid_statuses:
        return jsonify({"message": f"Invalid status. Must be one of {valid_statuses}"}), 400

    old_status = order.status
    if new_status == 'COMPLETED':
        from app.models.escrow import EscrowTransaction
        from app.routes.escrow import execute_order_escrow_release
        escrow = EscrowTransaction.query.filter_by(order_id=order.id).first()
        if escrow:
            execute_order_escrow_release(order, escrow, source=f"admin-{admin.id}")
        else:
            order.status = 'COMPLETED'
            db.session.commit()
    else:
        order.status = new_status
        db.session.commit()

    logger.info("[ADMIN] Admin %s updated Order #%s status from %s to %s", admin.id, order.id, old_status, new_status)

    return jsonify({
        "status": "success",
        "message": f"Order #{order.id} status updated to {new_status} and payout processed",
        "order": {"id": order.id, "status": order.status}
    }), 200


# ---------------------------------------------------------------------------
# Admin Financial Transactions Ledger
# ---------------------------------------------------------------------------

@admin_bp.route('/transactions', methods=['GET'])
@jwt_required()
def admin_get_transactions():
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    from sqlalchemy import func
    from app.models.withdrawal import DayaPayment, Withdrawal
    from app.models.escrow import EscrowTransaction, EscrowStatus

    page = request.args.get('page', 1, type=int)
    per_page = min(request.args.get('per_page', 50, type=int), 100)
    tx_type = (request.args.get('type') or 'ALL').strip().upper()
    search = (request.args.get('search') or '').strip()

    escrows = EscrowTransaction.query.order_by(EscrowTransaction.created_at.desc()).limit(200).all()
    daya_payments = DayaPayment.query.order_by(DayaPayment.created_at.desc()).limit(100).all()
    withdrawals = Withdrawal.query.order_by(Withdrawal.requested_at.desc()).limit(100).all()

    total_volume = float(db.session.query(func.sum(EscrowTransaction.amount)).scalar() or 0)
    total_fees = float(db.session.query(func.sum(EscrowTransaction.fee_amount)).scalar() or 0)
    pending_escrow = float(
        db.session.query(func.sum(EscrowTransaction.amount))
        .filter(EscrowTransaction.status.in_([EscrowStatus.IN_ESCROW, EscrowStatus.DISPUTED]))
        .scalar() or 0
    )
    total_payouts = float(
        db.session.query(func.sum(EscrowTransaction.amount - EscrowTransaction.fee_amount))
        .filter(EscrowTransaction.status == EscrowStatus.RELEASED)
        .scalar() or 0
    )

    transactions = []

    for e in escrows:
        o = e.order
        vendor = db.session.get(User, o.vendor_id) if o else None
        buyer = db.session.get(User, o.buyer_id) if (o and o.buyer_id) else None
        store = vendor.storefront if vendor else None

        transactions.append({
            "id": f"ESC-{e.id}",
            "reference": e.transaction_number,
            "type": "ESCROW_PAYMENT" if e.status != EscrowStatus.RELEASED else "ESCROW_RELEASED",
            "category": "Escrow",
            "amount": float(e.amount),
            "fee": float(e.fee_amount or 0),
            "currency": e.currency or "NGN",
            "provider": "PAYSTACK" if (o and (o.payment_method or '').upper() == 'PAYSTACK') else "DAYA",
            "status": e.status,
            "order_id": o.id if o else None,
            "vendor_name": store.store_name if store else (vendor.full_name if vendor else "Vendor"),
            "buyer_name": (buyer.full_name if buyer else None) or (o.buyer_name if o else None) or "Buyer",
            "created_at": e.created_at.isoformat() if e.created_at else None,
        })

    for dp in daya_payments:
        transactions.append({
            "id": f"DAYA-{dp.id}",
            "reference": dp.daya_deposit_id or f"DEP-{dp.id}",
            "type": "CRYPTO_DEPOSIT",
            "category": "Crypto / Daya",
            "amount": float(dp.amount_ngn or 0),
            "fee": 0.0,
            "currency": "NGN",
            "crypto_amount": dp.amount_crypto,
            "asset": dp.asset,
            "provider": "DAYA",
            "status": dp.status,
            "order_id": dp.order_id,
            "vendor_name": "Siiqo Platform",
            "buyer_name": dp.account_name or "Crypto Buyer",
            "created_at": dp.created_at.isoformat() if dp.created_at else None,
        })

    for w in withdrawals:
        v = db.session.get(User, w.vendor_id) if w.vendor_id else None
        vs = v.storefront if v else None
        transactions.append({
            "id": f"WD-{w.id}",
            "reference": w.transfer_reference or f"WD-{w.id}",
            "type": "VENDOR_WITHDRAWAL",
            "category": "Payout",
            "amount": float(w.amount or 0),
            "fee": float(w.fee_amount or 0),
            "currency": "NGN",
            "provider": "BANK_TRANSFER",
            "status": w.status,
            "order_id": None,
            "vendor_name": vs.store_name if vs else (v.full_name if v else "Vendor"),
            "buyer_name": "-",
            "created_at": w.requested_at.isoformat() if w.requested_at else None,
        })

    transactions.sort(key=lambda x: x["created_at"] or "", reverse=True)

    if tx_type and tx_type != "ALL":
        transactions = [t for t in transactions if tx_type in t["type"] or tx_type in t["category"].upper()]

    if search:
        s_low = search.lower()
        transactions = [
            t for t in transactions
            if s_low in str(t["reference"]).lower()
            or s_low in str(t.get("order_id") or "")
            or s_low in str(t["vendor_name"]).lower()
            or s_low in str(t["buyer_name"]).lower()
        ]

    total_count = len(transactions)
    start = (page - 1) * per_page
    end = start + per_page
    paginated_transactions = transactions[start:end]

    return jsonify({
        "status": "success",
        "summary": {
            "total_volume": total_volume,
            "total_fees": total_fees,
            "pending_escrow": pending_escrow,
            "total_payouts": total_payouts,
        },
        "transactions": paginated_transactions,
        "total": total_count,
        "page": page,
        "per_page": per_page,
    }), 200


@admin_bp.route('/escrow/refund/<int:order_id>', methods=['POST'])
@jwt_required()
@limiter.limit("20 per hour")  # Strict rate limit on financial operations
@detect_anomalies
def admin_refund_buyer(order_id):
    """
    Admin refunds the buyer (dispute resolved in buyer's favour).
    Calls PayScrow's broker refund endpoint to reverse the transaction,
    then marks the escrow as REFUNDED and notifies both parties.
    
    Security: Rate limited, anomaly detected, fully audit logged.
    """
    admin_id = get_jwt_identity()
    admin = _require_superadmin(_parse_admin_id(admin_id))
    if not admin:
        return jsonify({"message": "SuperAdmin required"}), 403

    escrow = EscrowTransaction.query.filter_by(order_id=order_id).first()
    if not escrow:
        return jsonify({"message": "Escrow transaction not found"}), 404

    if escrow.status == EscrowStatus.REFUNDED:
        return jsonify({"message": "Funds already refunded"}), 400

    if escrow.status == EscrowStatus.RELEASED:
        return jsonify({"message": "Funds already released to vendor — cannot refund"}), 400

    # Call PayScrow broker refund / cancel endpoint
    if escrow.payscrow_ref:
        import os, requests as _requests
        payscrow_key = os.environ.get('PAYSCROW_API_KEY', '')
        base_url = os.environ.get('PAYSCROW_BASE_URL')
        if not base_url:
            _is_sandbox = (
                not payscrow_key
                or payscrow_key.startswith('ps_9')
                or os.environ.get('PAYSCROW_ENV', '').lower() == 'sandbox'
            )
            base_url = "https://api.payscrow.dev" if _is_sandbox else "https://api.payscrow.net"
        headers = {"BrokerApiKey": payscrow_key, "Content-Type": "application/json"}
        try:
            resp = _requests.post(
                f"{base_url}/api/v3/marketplace/transactions/{escrow.payscrow_ref}/broker/refund",
                json={"reason": "Admin dispute resolution — refund to buyer"},
                headers=headers,
                timeout=15,
            )
            resp_data = resp.json()
            if not resp_data.get('success'):
                logging.warning(
                    f"[ADMIN REFUND] PayScrow refund returned non-success for Order #{order_id}: {resp.text}"
                )
                # Continue — still update our DB so order isn't stuck
        except Exception as e:
            logging.error(f"[ADMIN REFUND] PayScrow refund error for Order #{order_id}: {e}")
    else:
        logging.warning(
            f"[ADMIN REFUND] Order #{order_id} has no payscrow_ref — skipping PayScrow call."
        )

    escrow.status = EscrowStatus.REFUNDED
    order = escrow.order
    if order:
        if order.status != 'CANCELLED':
            for item in order.items:
                if item.product:
                    item.product.stock_quantity = (item.product.stock_quantity or 0) + item.quantity
        order.status = 'CANCELLED'

    # Notify buyer — they get their money back
    if order and order.buyer_id:
        db.session.add(Notification(
            user_id=order.buyer_id,
            title="Refund Processed",
            message=f"Your dispute for Order #{order_id} was resolved in your favour. A refund of ₦{float(escrow.amount):,.2f} has been initiated.",
            type="ESCROW",
            order_id=order_id,
        ))
        # Notify vendor — they don't get paid
        db.session.add(Notification(
            user_id=order.vendor_id,
            title="Dispute Resolved — Refund Issued",
            message=f"The dispute for Order #{order_id} was resolved in the buyer's favour. Funds have been refunded to the buyer.",
            type="ESCROW",
            order_id=order_id,
        ))

    db.session.commit()
    
    # Audit log the refund
    AdminAuditLog.log_action(
        admin=admin,
        action='ESCROW_REFUND',
        resource_type='EscrowTransaction',
        resource_id=escrow.transaction_number,
        details={
            'order_id': order_id,
            'amount': float(escrow.amount),
            'buyer_id': order.buyer_id if order else None,
            'vendor_id': order.vendor_id if order else None,
            'payscrow_ref': escrow.payscrow_ref,
            'reason': 'Admin dispute resolution',
        }
    )
    
    logging.warning(f"[ADMIN CRITICAL] Escrow refund processed for Order #{order_id} by {admin.email}")

    # Trigger trust score recalculation on dispute lost
    try:
        from app.services.trust import recalculate_vendor_trust
        if order:
            recalculate_vendor_trust(order.vendor_id, reason="Dispute Resolved (Refunded)")
    except Exception as e:
        logging.error(f"[TRUST ERROR] Failed to recalculate trust on admin refund: {e}")

    return jsonify({"message": "Refund processed successfully.", "status": "success"}), 200


@admin_bp.route('/escrow/verify/<int:order_id>', methods=['POST'])
@jwt_required()
def admin_verify_payment(order_id):
    """Admin manually marks a payment as received (for bank transfer cases)."""
    from app.models.order import Order
    admin_id = get_jwt_identity()
    try:
        parsed_id = _parse_admin_id(admin_id)
    except (ValueError, TypeError):
        return jsonify({"message": "Unauthorized"}), 401
    if not _get_admin(parsed_id):
        return jsonify({"message": "Unauthorized"}), 403

    order = db.session.get(Order, order_id)
    if not order:
        return jsonify({"message": f"Order #{order_id} not found"}), 404

    escrow = EscrowTransaction.query.filter_by(order_id=order_id).first()
    if not escrow:
        return jsonify({"message": f"No escrow record for Order #{order_id}"}), 404

    escrow.status = EscrowStatus.IN_ESCROW
    db.session.commit()

    logging.info(f"[ADMIN] Escrow verified for Order #{order_id} by admin {parsed_id}")
    return jsonify({"message": f"Order #{order_id} marked as verified and held in escrow.", "status": "success"}), 200


# ---------------------------------------------------------------------------
# POST /admin/escrow/fix-crypto-order/<order_id>
# Marks a crypto order as COMPLETED when it got stuck in PENDING due to
# a backend error (e.g. Notification import crash on Order #226-228).
# ---------------------------------------------------------------------------

@admin_bp.route('/escrow/fix-crypto-order/<int:order_id>', methods=['POST'])
@jwt_required()
def admin_fix_crypto_order(order_id):
    """
    Admin route to fix crypto/Daya/escrow orders stuck in PENDING status,
    or re-trigger digital delivery, vendor ledger credit & vendor payout.
    """
    from app.models.order import Order
    from app.models.communication import Notification
    from app.routes.events import activate_tickets_for_order
    from app.routes.escrow import _deliver_digital_products, _deliver_service_products, _credit_vendor_ledger
    from app.routes.payments import _payout_vendor_via_daya
    from app.utils.email import send_siiqo_email

    admin_id = get_jwt_identity()
    try:
        parsed_id = _parse_admin_id(admin_id)
    except (ValueError, TypeError):
        return jsonify({"message": "Unauthorized"}), 401
    if not _get_admin(parsed_id):
        return jsonify({"message": "Unauthorized"}), 403

    order = db.session.get(Order, order_id)
    if not order:
        return jsonify({"message": f"Order #{order_id} not found"}), 404

    escrow = EscrowTransaction.query.filter_by(order_id=order_id).first()
    if not escrow:
        return jsonify({"message": f"No escrow record for Order #{order_id}"}), 404

    old_order_status  = order.status
    old_escrow_status = escrow.status

    # Mark as PAID and escrow as IN_ESCROW as base state before releasing
    order.status = 'PAID'
    escrow.status = EscrowStatus.IN_ESCROW
    escrow.paid_at = escrow.paid_at or _utcnow()
    db.session.flush()

    # 1. Event Ticket Order?
    is_ticket = activate_tickets_for_order(order_id)
    if is_ticket:
        net_amount = float(escrow.amount) - float(escrow.fee_amount or 0)
        escrow.status = EscrowStatus.RELEASED
        escrow.released_at = escrow.released_at or _utcnow()
        order.status = 'COMPLETED'
        _credit_vendor_ledger(
            vendor_id=order.vendor_id,
            amount=net_amount,
            reference_id=escrow.transaction_number,
            description=f"Admin-released payout for Event Order #{order.id}",
        )
        try:
            _payout_vendor_via_daya(order, escrow)
        except Exception as e:
            logging.warning(f"[ADMIN FIX] Daya payout warning: {e}")

    # 2. Digital Order?
    is_digital = _deliver_digital_products(order, escrow)
    is_service = False
    if not is_digital and not is_ticket:
        is_service = _deliver_service_products(order, escrow)

    # 3. Pay Link Digital/Service?
    if not is_digital and not is_service and not is_ticket and order.payment_link_id:
        from app.models.payment_link import PaymentLink as _PL
        _link = db.session.get(_PL, order.payment_link_id)
        _ltype = getattr(_link, 'product_type', 'physical') or 'physical'
        if _ltype in ('digital', 'service'):
            net_amount = float(escrow.amount) - float(escrow.fee_amount or 0)
            escrow.status = EscrowStatus.RELEASED
            escrow.released_at = escrow.released_at or _utcnow()
            order.status = 'COMPLETED'
            if _link:
                _link.status = 'PAID'
            _credit_vendor_ledger(
                vendor_id=order.vendor_id,
                amount=net_amount,
                reference_id=escrow.transaction_number,
                description=f"Admin-released payout for {_ltype.title()} PayLink #{order.id}",
            )
            try:
                _payout_vendor_via_daya(order, escrow)
            except Exception as e:
                logging.warning(f"[ADMIN FIX] Daya payout warning: {e}")
            is_digital = (_ltype == 'digital')
            is_service = (_ltype == 'service')

    # 4. Physical Order (or fallback)
    if not is_digital and not is_service and not is_ticket:
        net_amount = float(escrow.amount) - float(escrow.fee_amount or 0)
        escrow.status = EscrowStatus.RELEASED
        escrow.released_at = escrow.released_at or _utcnow()
        order.status = 'COMPLETED'
        _credit_vendor_ledger(
            vendor_id=order.vendor_id,
            amount=net_amount,
            reference_id=escrow.transaction_number,
            description=f"Admin-released payout for Order #{order.id}",
        )
        try:
            _payout_vendor_via_daya(order, escrow)
        except Exception as e:
            logging.warning(f"[ADMIN FIX] Daya payout warning: {e}")

    # If digital or service order, trigger Daya vendor payout if crypto/Daya
    if is_digital or is_service:
        try:
            _payout_vendor_via_daya(order, escrow)
        except Exception as e:
            logging.warning(f"[ADMIN FIX] Daya payout warning: {e}")

    # Send notifications
    if order.buyer_id:
        db.session.add(Notification(
            user_id=order.buyer_id,
            title="Order Completed",
            message=f"Your payment for Order #{order_id} is confirmed and the order is complete.",
            type="ORDER",
            order_id=order_id,
        ))
    db.session.add(Notification(
        user_id=order.vendor_id,
        title="Order Complete",
        message=f"Order #{order_id} has been marked complete and funds released by admin.",
        type="ESCROW",
        order_id=order_id,
    ))

    # Also email guest buyer if not already sent by _deliver_digital_products
    buyer_email = (order.buyer.email if order.buyer else None) or getattr(order, 'buyer_email', None)
    if buyer_email and not is_digital:
        buyer_first_name = (order.buyer.first_name if order.buyer else None) or getattr(order, 'buyer_name', None) or "there"
        try:
            send_siiqo_email(
                to_email=buyer_email,
                subject=f"Order #{order.id} Confirmed | Siiqo",
                template_name="system_notice",
                first_name=buyer_first_name,
                notice_text=f"Your payment for Order #{order.id} has been confirmed.",
            )
        except Exception as e:
            logging.warning(f"[ADMIN FIX] guest confirmation email warning: {e}")

    db.session.commit()

    logging.info(
        "[ADMIN FIX] Order #%s status %s->COMPLETED, escrow %s->RELEASED",
        order_id, old_order_status, old_escrow_status
    )

    return jsonify({
        "message": f"Order #{order_id} fixed and completed successfully. Vendor credited and buyer notified.",
        "order_status": "COMPLETED",
        "escrow_status": "RELEASED",
        "previous_order_status": old_order_status,
        "previous_escrow_status": old_escrow_status,
    }), 200


@admin_bp.route('/escrow/release/<int:order_id>', methods=['POST'])
@jwt_required()
def admin_release_funds(order_id):
    """Admin force-releases escrow funds (e.g., after dispute resolution)."""
    admin_id = get_jwt_identity()
    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    escrow = EscrowTransaction.query.filter_by(order_id=order_id).first()
    if not escrow:
        return jsonify({"message": "Escrow transaction not found"}), 404

    # Call PayScrow's applycode to actually move the money — required for DISPUTED orders
    # where funds are frozen on PayScrow's side.
    if escrow.payscrow_transaction_id and escrow.escrow_code:
        import os, requests as _requests
        payscrow_key = os.environ.get('PAYSCROW_API_KEY', '')
        base_url = os.environ.get('PAYSCROW_BASE_URL')
        if not base_url:
            _is_sandbox = (
                not payscrow_key
                or payscrow_key.startswith('ps_9')
                or os.environ.get('PAYSCROW_ENV', '').lower() == 'sandbox'
            )
            base_url = "https://api.payscrow.dev" if _is_sandbox else "https://api.payscrow.net"
        headers = {"BrokerApiKey": payscrow_key, "Content-Type": "application/json"}
        try:
            resp = _requests.post(
                f"{base_url}/api/v3/escrow/escrowtransactions/applycode",
                json={"transactionId": escrow.payscrow_transaction_id, "code": escrow.escrow_code},
                headers=headers,
                timeout=15,
            )
            resp_data = resp.json()
            if not resp_data.get('success'):
                logging.warning(
                    f"[ADMIN RELEASE] PayScrow applycode returned non-success for Order #{order_id}: {resp.text}"
                )
        except Exception as e:
            logging.error(f"[ADMIN RELEASE] PayScrow applycode error for Order #{order_id}: {e}")
    else:
        logging.warning(
            f"[ADMIN RELEASE] Order #{order_id} has no payscrow_transaction_id or escrow_code — "
            "skipping PayScrow applycode call (manual bank transfer or missing data)."
        )

    escrow.status = EscrowStatus.RELEASED
    escrow.released_at = _utcnow()
    order = escrow.order
    if order:
        order.status = 'COMPLETED'
        net_amount = float(escrow.amount) - float(escrow.fee_amount or 0)
        _credit_vendor_ledger(
            vendor_id=order.vendor_id,
            amount=net_amount,
            reference_id=escrow.transaction_number,
            description=f"Admin-released payout for Order #{order.id}",
        )

        # Also trigger digital delivery if digital
        from app.routes.escrow import _deliver_digital_products
        is_dig = _deliver_digital_products(order, escrow)

        # Trigger Daya payout if order used Daya/crypto
        try:
            from app.routes.payments import _payout_vendor_via_daya
            _payout_vendor_via_daya(order, escrow)
        except Exception as payout_err:
            logging.warning(f"[ADMIN RELEASE] Daya payout warning: {payout_err}")

        db.session.add(Notification(
            user_id=order.vendor_id,
            title="Funds Released by Admin",
            message=f"₦{net_amount:,.2f} has been credited to your ledger for Order #{order.id}.",
            type="ESCROW",
            order_id=order.id,
        ))
        # Also notify buyer
        if order.buyer_id:
            db.session.add(Notification(
                user_id=order.buyer_id,
                title="Order Complete",
                message=f"Order #{order.id} has been resolved by Siiqo support. The order is now complete.",
                type="ORDER",
                order_id=order.id,
            ))
        else:
            # Guest buyer
            buyer_email = getattr(order, 'buyer_email', None)
            if buyer_email and not is_dig:
                try:
                    from app.utils.email import send_siiqo_email
                    send_siiqo_email(
                        to_email=buyer_email,
                        subject=f"Order #{order.id} Resolved | Siiqo",
                        template_name="system_notice",
                        first_name=getattr(order, 'buyer_name', None) or "there",
                        notice_text=f"Your payment and order #{order.id} have been completed by support.",
                    )
                except Exception:
                    pass

    db.session.commit()

    # Trigger trust score recalculation on dispute won / admin release
    try:
        from app.services.trust import recalculate_vendor_trust
        if order:
            recalculate_vendor_trust(order.vendor_id, reason="Dispute Resolved (Released)")
    except Exception as e:
        logging.error(f"[TRUST ERROR] Failed to recalculate trust on admin release: {e}")

    return jsonify({"message": "Funds released successfully.", "status": "success"}), 200


# ---------------------------------------------------------------------------
# Partners
# ---------------------------------------------------------------------------

@admin_bp.route('/partners/applications', methods=['GET'])
@jwt_required()
def get_partnerships():
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    applications = PartnerApplication.query.order_by(PartnerApplication.applied_at.desc()).limit(500).all()
    return jsonify({
        "partners": [{
            "id": p.id,
            "business_name": p.business_name,
            "service_type": p.service_type,
            "partner_role": p.service_type,         # alias so frontend field names work
            "status": p.status,
            "state_of_operation": p.state_of_operation,
            "experience_years": p.experience_years,
            "portfolio_url": p.portfolio_url,
            "applied_at": p.applied_at.isoformat() if p.applied_at else None,
            "reviewed_at": p.reviewed_at.isoformat() if p.reviewed_at else None,
            # Bank payout details
            "bank_name": p.account_name or "",
            "account_number": p.account_number or "",
            "account_name": p.account_name or "",
            "bank_code": p.bank_code or "",
            # Applicant contact — use both field name conventions so old + new frontend works
            "applicant": {
                "name": p.user.full_name if p.user else "Unknown",
                "email": p.user.email if p.user else "",
                "phone": p.user.phone if p.user else "",
            },
            "contact_email": p.user.email if p.user else "",
            "contact_phone": p.user.phone if p.user else "",
            "user_id": p.user.id if p.user else None,
        } for p in applications],
        "count": len(applications),
    }), 200


@admin_bp.route('/partners/<int:app_id>/status', methods=['PATCH'])
@jwt_required()
def update_partner_status(app_id):
    admin_id = get_jwt_identity()
    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    app = db.session.get(PartnerApplication, app_id)
    if not app:
        return jsonify({"message": "Application not found"}), 404

    data = request.get_json() or {}
    status = (data.get('status') or '').upper()

    if status == 'APPROVED':
        app.status = 'APPROVED'
        app.reviewed_at = _utcnow()
        if app.user:
            app.user.role = 'PARTNER'
            app.user.is_verified = True
            try:
                send_siiqo_email(
                    to_email=app.user.email,
                    subject="Welcome to the Siiqo Partner Network!",
                    template_name="system_notice",
                    header="Application Approved",
                    body=(
                        f"Hi {app.user.full_name}, your partner application for {app.business_name} "
                        "has been approved. You can now log in to your partner dashboard."
                    ),
                )
            except Exception:
                pass
    elif status in ('REJECTED', 'ACTIVE', 'SUSPENDED'):
        app.status = status
        app.reviewed_at = _utcnow()
    else:
        return jsonify({"message": "Invalid status"}), 400

    db.session.commit()
    return jsonify({"message": f"Partner application {status.lower()}.", "status": "success"}), 200


# Backward-compat alias
@admin_bp.route('/partnerships/<int:app_id>/approve', methods=['POST'])
@jwt_required()
def approve_partnership(app_id):
    admin_id = get_jwt_identity()
    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    app = db.session.get(PartnerApplication, app_id)
    if not app:
        return jsonify({"message": "Application not found"}), 404

    app.status = 'APPROVED'
    app.reviewed_at = _utcnow()
    if app.user:
        app.user.role = 'PARTNER'
        app.user.is_verified = True
    db.session.commit()
    return jsonify({"message": f"Partnership {app.business_name} approved."}), 200


# ---------------------------------------------------------------------------
# Blog Authors
# ---------------------------------------------------------------------------

@admin_bp.route('/blog/authors', methods=['GET', 'POST'])
@jwt_required()
def handle_blog_authors():
    """List or create blog author profiles."""
    admin_id = get_jwt_identity()
    parsed_id = _parse_admin_id(admin_id)
    if not _get_admin(parsed_id):
        return jsonify({"message": "Unauthorized"}), 403

    if request.method == 'GET':
        authors = BlogAuthor.query.filter_by(is_active=True).order_by(BlogAuthor.name).all()
        return jsonify({"authors": [
            {
                "id": a.id,
                "name": a.name,
                "slug": a.slug,
                "title": a.title,
                "bio": a.bio,
                "avatar": a.avatar,
                "twitter_handle": a.twitter_handle,
                "linkedin_url": a.linkedin_url,
            } for a in authors
        ]}), 200

    # POST — create a new author profile
    if not _require_superadmin(parsed_id):
        return jsonify({"message": "SuperAdmin required"}), 403

    import re as _re
    # Support multipart (avatar upload) and JSON
    if request.content_type and 'multipart' in request.content_type:
        data = request.form.to_dict()
        avatar_file = request.files.get('avatar')
        avatar_url = None
        if avatar_file:
            from app.utils.upload import save_uploaded_file
            avatar_url = save_uploaded_file(avatar_file, subfolder="authors")
    else:
        data = request.get_json() or {}
        avatar_url = data.get('avatar')

    name = (data.get('name') or '').strip()
    if not name:
        return jsonify({"message": "Author name is required."}), 400

    slug = _re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')
    original_slug = slug
    import uuid as _uuid
    while BlogAuthor.query.filter_by(slug=slug).first():
        slug = f"{original_slug}-{str(_uuid.uuid4())[:6]}"

    author = BlogAuthor(
        name=name,
        slug=slug,
        title=data.get('title'),
        bio=data.get('bio'),
        avatar=avatar_url,
        twitter_handle=data.get('twitter_handle'),
        linkedin_url=data.get('linkedin_url'),
        is_active=True,
    )
    db.session.add(author)
    db.session.commit()
    return jsonify({"message": "Author created.", "id": author.id, "slug": author.slug}), 201


@admin_bp.route('/blog/authors/<int:author_id>', methods=['PATCH', 'DELETE'])
@jwt_required()
def manage_blog_author(author_id):
    """Update or deactivate a blog author."""
    admin_id = get_jwt_identity()
    parsed_id = _parse_admin_id(admin_id)
    if not _require_superadmin(parsed_id):
        return jsonify({"message": "SuperAdmin required"}), 403

    author = db.session.get(BlogAuthor, author_id)
    if not author:
        return jsonify({"message": "Author not found"}), 404

    if request.method == 'DELETE':
        author.is_active = False
        db.session.commit()
        return jsonify({"message": "Author deactivated."}), 200

    # PATCH
    if request.content_type and 'multipart' in request.content_type:
        data = request.form.to_dict()
        avatar_file = request.files.get('avatar')
        if avatar_file:
            from app.utils.upload import save_uploaded_file
            s3_url = save_uploaded_file(avatar_file, subfolder="authors")
            if s3_url:
                author.avatar = s3_url
    else:
        data = request.get_json() or {}
        if 'avatar' in data:
            author.avatar = data['avatar']

    if 'name' in data and data['name']:
        author.name = data['name'].strip()
    if 'title' in data:
        author.title = data['title']
    if 'bio' in data:
        author.bio = data['bio']
    if 'twitter_handle' in data:
        author.twitter_handle = data['twitter_handle']
    if 'linkedin_url' in data:
        author.linkedin_url = data['linkedin_url']

    db.session.commit()
    return jsonify({"message": "Author updated."}), 200


# Blog
# ---------------------------------------------------------------------------

@admin_bp.route('/blog', methods=['GET', 'POST'])
@jwt_required()
def handle_blog():
    admin_id = get_jwt_identity()
    parsed_id = _parse_admin_id(admin_id)
    admin = _get_admin(parsed_id)
    if not admin:
        return jsonify({"message": "Unauthorized"}), 403

    if request.method == 'GET':
        articles = Article.query.order_by(Article.created_at.desc()).limit(500).all()
        return jsonify({
            "articles": [{
                "id": a.id,
                "title": a.title,
                "slug": a.slug,
                "category": a.category,
                "excerpt": a.excerpt,
                "cover_image": a.cover_image,
                "status": "published" if a.is_published else "draft",
                "is_published": a.is_published,
                "created_at": a.created_at.isoformat() if a.created_at else None,
            } for a in articles]
        }), 200

    if not _require_superadmin(parsed_id):
        return jsonify({"message": "SuperAdmin required"}), 403

    import re

    # Support both JSON and multipart/form-data (for image uploads)
    if request.content_type and 'multipart' in request.content_type:
        data = request.form.to_dict()
        cover_image_file = request.files.get('cover_image')
        cover_image_url = None
        if cover_image_file:
            import os, uuid
            from app.utils.upload import save_uploaded_file
            s3_url = save_uploaded_file(cover_image_file, subfolder="blog")
            if s3_url:
                cover_image_url = s3_url
    else:
        data = request.get_json() or {}
        cover_image_url = data.get('cover_image')

    title = data.get('title', '')
    if not title:
        return jsonify({"message": "Title is required"}), 400
    raw_slug = data.get('slug') or title
    slug = re.sub(r'[^a-z0-9]+', '-', raw_slug.lower()).strip('-')
    if not slug:
        slug = f"article-{str(uuid.uuid4())[:8]}"

    # Ensure slug is unique across both live articles and historical 301 redirects
    original_slug = slug
    import uuid
    while Article.query.filter_by(slug=slug).first() or ArticleSlugRedirect.query.filter_by(old_slug=slug).first():
        slug = f"{original_slug}-{str(uuid.uuid4())[:6]}"

    # Resolve author from author_id or fallback to plain author_name text
    author_id_val = data.get('author_id')
    resolved_author_name = data.get('author') or data.get('author_name')
    if author_id_val:
        linked_author = db.session.get(BlogAuthor, int(author_id_val))
        if linked_author:
            resolved_author_name = linked_author.name
    else:
        linked_author = None

    try:
        new_article = Article(
            admin_author_id=parsed_id,
            author_id=linked_author.id if linked_author else None,
            title=title,
            slug=slug,
            category=data.get('category'),
            sub_category=data.get('sub_category'),
            author_name=resolved_author_name,
            content=data.get('content', ''),
            excerpt=data.get('excerpt'),
            cover_image=cover_image_url,
            is_published=data.get('is_published', False) in (True, 'true', '1', 'published'),
            meta_title=data.get('meta_title') or data.get('seo_title'),
            meta_description=data.get('meta_description') or data.get('seo_description'),
        )
        db.session.add(new_article)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        import logging
        logging.error(f"[BLOG ADMIN] Failed to create article: {e}")
        return jsonify({"message": f"Failed to create article: {str(e)}"}), 500

    if new_article.is_published:
        _auto_post_blog_to_community(new_article)

    return jsonify({"message": "Article created.", "id": new_article.id, "slug": new_article.slug}), 201


def _auto_post_blog_to_community(article):
    """Auto-post a published blog article to the community feed.
    Posts are always authored by the official 'Siiqo Editorial' brand user account.
    The credited author name/title is displayed in the post body.
    No new users are ever created in the users table by this function.
    """
    try:
        from app.models.social import Post as CommunityPost
        from app.models.user import User
        import re

        # ── Use the official Siiqo Editorial brand account ─────────
        editorial_user = User.query.filter_by(email='editorial@siiqo.com').first()
        if not editorial_user:
            # Fallback: first admin user if editorial account doesn't exist yet
            editorial_user = User.query.filter_by(role='ADMIN').order_by(User.id).first()
        if not editorial_user:
            logging.warning("[BLOG AUTO-POST] No editorial user found; skipping community post.")
            return

        poster_id = editorial_user.id

        # ── Build author credit line ───────────────────────────────
        # Prefer linked BlogAuthor profile; fallback to article.author_name
        author_credit = ""
        if article.author and article.author.name:
            if article.author.title:
                author_credit = f"✍️ By {article.author.name} ({article.author.title})"
            else:
                author_credit = f"✍️ By {article.author.name}"
        elif article.author_name:
            author_credit = f"✍️ By {article.author_name}"
        else:
            author_credit = "✍️ By Siiqo Editorial Team"

        # ── Build excerpt ─────────────────────────────────────────
        excerpt_text = article.excerpt or ""
        if not excerpt_text and article.content:
            clean_text = re.sub('<[^<]+?>', '', article.content)
            excerpt_text = clean_text[:180] + "..." if len(clean_text) > 180 else clean_text

        article_url = f"https://siiqo.com/blog/{article.slug}"
        post_content = (
            f"📰 NEW ARTICLE ON SIIQO BLOG!\n\n"
            f"✨ {article.title}\n\n"
            f"{author_credit}\n\n"
            f"{excerpt_text}\n\n"
            f"👉 Read full article: {article_url}"
        )

        cover_imgs = [
            article.cover_image
        ] if article.cover_image and isinstance(article.cover_image, str) and article.cover_image.strip() else []

        # ── Upsert community post ─────────────────────────────────
        existing = CommunityPost.query.filter(
            CommunityPost.content.like(f"%{article.slug}%")
        ).first()

        if existing and article.is_published:
            existing.user_id = poster_id
            existing.content = post_content
            existing.images = cover_imgs
            db.session.commit()
        elif not existing and article.is_published:
            community_post = CommunityPost(
                user_id=poster_id,
                post_type='ANNOUNCEMENT',
                content=post_content,
                images=cover_imgs,
            )
            db.session.add(community_post)
            db.session.commit()

    except Exception as e:
        db.session.rollback()
        import logging
        logging.warning(f"[BLOG AUTO-POST] Auto community post failed for article {article.id}: {e}")


@admin_bp.route('/blog/<int:article_id>', methods=['GET', 'PATCH', 'DELETE'])
@jwt_required()
def manage_blog_article(article_id):
    """Get, edit, or delete a specific blog article by ID."""
    admin_id = get_jwt_identity()
    parsed_id = _parse_admin_id(admin_id)
    if not _require_superadmin(parsed_id):
        return jsonify({"message": "SuperAdmin required"}), 403

    article = db.session.get(Article, article_id)
    if not article:
        return jsonify({"message": "Article not found"}), 404

    if request.method == 'GET':
        # Return full article details for editing + active redirects
        redirect_list = [r.old_slug for r in article.slug_redirects] if getattr(article, 'slug_redirects', None) else []
        return jsonify({
            "id": article.id,
            "title": article.title,
            "author": article.author_name,
            "author_name": article.author_name,
            "author_id": article.author_id,
            "slug": article.slug,
            "redirects": redirect_list,
            "content": article.content,
            "category": article.category,
            "sub_category": article.sub_category,
            "excerpt": article.excerpt,
            "cover_image": article.cover_image,
            "is_published": article.is_published,
            "status": "published" if article.is_published else "draft",
            "meta_title": article.meta_title,
            "meta_description": article.meta_description,
            "created_at": article.created_at.isoformat() if article.created_at else None,
        }), 200

    if request.method == 'DELETE':
        article_slug = article.slug
        article_title = article.title
        try:
            # Clean up corresponding community announcement posts
            from app.models.social import Post as CommunityPost
            community_posts = CommunityPost.query.filter(
                CommunityPost.content.like(f"%{article_slug}%")
            ).all()
            for cp in community_posts:
                db.session.delete(cp)
        except Exception as e:
            import logging
            logging.warning(f"[BLOG DELETE] Could not delete community posts for article {article.id}: {e}")

        try:
            db.session.delete(article)
            db.session.commit()
            return jsonify({"message": f"Article '{article_title}' and community post deleted."}), 200
        except Exception as e:
            db.session.rollback()
            return jsonify({"message": f"Failed to delete article: {str(e)}"}), 500

    # PATCH — update existing article
    import re

    if request.content_type and 'multipart' in request.content_type:
        data = request.form.to_dict()
        cover_image_file = request.files.get('cover_image')
        if cover_image_file:
            import os, uuid
            from app.utils.upload import save_uploaded_file
            s3_url = save_uploaded_file(cover_image_file, subfolder="blog")
            if s3_url:
                article.cover_image = s3_url
    else:
        data = request.get_json() or {}
        if 'cover_image' in data and isinstance(data['cover_image'], str):
            article.cover_image = data['cover_image']

    if 'title' in data and data['title']:
        article.title = data['title']
        # NOTE: DO NOT TOUCH article.slug WHEN TITLE CHANGES! Title & URL slug are decoupled.

    # Only update slug if explicitly provided in payload and different from current canonical slug
    if 'slug' in data and data['slug']:
        requested_slug = re.sub(r'[^a-z0-9]+', '-', str(data['slug']).lower()).strip('-')
        if requested_slug and requested_slug != article.slug:
            # 1. Reject if slug belongs to another active article
            existing_article = Article.query.filter(Article.slug == requested_slug, Article.id != article_id).first()
            if existing_article:
                return jsonify({
                    "message": f"URL Slug '{requested_slug}' is already in use by article #{existing_article.id} ('{existing_article.title}'). Please choose a unique slug."
                }), 400

            # 2. Reject if slug is an old redirect belonging to a different article
            existing_redirect = ArticleSlugRedirect.query.filter(
                ArticleSlugRedirect.old_slug == requested_slug,
                ArticleSlugRedirect.article_id != article_id
            ).first()
            if existing_redirect:
                return jsonify({
                    "message": f"URL Slug '{requested_slug}' is already registered as a 301 redirect for article #{existing_redirect.article_id}. Please choose a unique slug."
                }), 400

            old_slug_to_save = article.slug

            # 3. Prevent redirect loops & chains:
            # If the new slug was previously an old redirect FOR THIS SAME ARTICLE (e.g. reverting to an earlier URL),
            # remove that redirect entry so it doesn't self-reference.
            same_article_redirect = ArticleSlugRedirect.query.filter_by(article_id=article_id, old_slug=requested_slug).first()
            if same_article_redirect:
                db.session.delete(same_article_redirect)

            # 4. Record old_slug in article_slug_redirects for this article if not already present
            existing_old_record = ArticleSlugRedirect.query.filter_by(article_id=article_id, old_slug=old_slug_to_save).first()
            if not existing_old_record:
                new_redirect = ArticleSlugRedirect(
                    article_id=article.id,
                    old_slug=old_slug_to_save
                )
                db.session.add(new_redirect)

            # Set new canonical slug
            article.slug = requested_slug
    if 'category' in data:
        article.category = data['category']
    if 'sub_category' in data:
        article.sub_category = data['sub_category']
    if 'author_id' in data and data['author_id']:
        linked_author = db.session.get(BlogAuthor, int(data['author_id']))
        if linked_author:
            article.author_id = linked_author.id
            article.author_name = linked_author.name
    elif 'author' in data or 'author_name' in data:
        article.author_name = data.get('author') or data.get('author_name')
    if 'content' in data:
        article.content = data['content']
    if 'excerpt' in data:
        article.excerpt = data['excerpt']
    if 'status' in data:
        article.is_published = data['status'] in ('published', True, 'true', '1')
    if 'is_published' in data:
        article.is_published = data['is_published'] in (True, 'true', '1', 'published')
    if 'meta_title' in data or 'seo_title' in data:
        article.meta_title = data.get('meta_title') or data.get('seo_title')
    if 'meta_description' in data or 'seo_description' in data:
        article.meta_description = data.get('meta_description') or data.get('seo_description')

    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        import logging
        logging.error(f"[BLOG ADMIN] Failed to update article {article_id}: {e}")
        return jsonify({"message": f"Failed to update article: {str(e)}"}), 500

    if article.is_published:
        _auto_post_blog_to_community(article)
    else:
        try:
            from app.models.social import Post as CommunityPost
            community_posts = CommunityPost.query.filter(
                CommunityPost.content.like(f"%{article.slug}%")
            ).all()
            for cp in community_posts:
                db.session.delete(cp)
            db.session.commit()
        except Exception:
            pass

    return jsonify({"message": "Article updated.", "id": article.id}), 200




# ---------------------------------------------------------------------------
# Platform Settings
# ---------------------------------------------------------------------------

@admin_bp.route('/settings', methods=['GET', 'POST'])
@jwt_required()
def manage_platform_settings():
    admin_id = get_jwt_identity()
    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    if request.method == 'GET':
        settings = PlatformSetting.query.all()
        return jsonify([{
            "key": s.key,
            "value": s.value,
            "description": s.description,
        } for s in settings]), 200

    data = request.get_json() or {}
    key = data.get('key')
    value = data.get('value')
    if not key:
        return jsonify({"message": "key is required"}), 400

    setting = PlatformSetting.query.filter_by(key=key).first()
    if not setting:
        setting = PlatformSetting(key=key, value=value, description=data.get('description'))
        db.session.add(setting)
    else:
        setting.value = value
    db.session.commit()
    return jsonify({"message": f"Setting '{key}' updated."}), 200


# ---------------------------------------------------------------------------
# Broadcast Email
# ---------------------------------------------------------------------------

@admin_bp.route('/broadcast', methods=['POST'])
@jwt_required()
def send_email_broadcast():
    admin_id = get_jwt_identity()
    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    data = request.get_json() or {}
    target_audience = str(data.get('target_audience') or data.get('audience', 'ALL')).upper()
    subject = data.get('subject', '')
    body = data.get('body', '')
    critical = data.get('critical', False)

    if not subject or not body:
        return jsonify({"message": "Subject and body are required"}), 400

    if target_audience == 'VENDORS':
        recipients = User.query.filter_by(role='VENDOR', is_subscribed_to_broadcasts=True).all()
    elif target_audience == 'BUYERS':
        recipients = User.query.filter_by(role='BUYER', is_subscribed_to_broadcasts=True).all()
    elif target_audience == 'PARTNERS':
        recipients = User.query.filter_by(role='PARTNER', is_subscribed_to_broadcasts=True).all()
    elif target_audience == 'CUSTOM':
        custom_emails_raw = data.get('customEmails') or data.get('custom_emails', '')
        custom_emails = [e.strip() for e in custom_emails_raw.split(',') if e.strip()]
        if not custom_emails:
            return jsonify({"message": "No valid email addresses provided for custom broadcast"}), 400
        class _FakeUser:
            def __init__(self, email):
                self.email = email
                self.first_name = None
                self.is_subscribed_to_broadcasts = True
        recipients = [_FakeUser(e) for e in custom_emails]
    else:
        recipients = User.query.filter_by(is_subscribed_to_broadcasts=True).all()

    sent, failed, skipped = 0, 0, 0
    import hashlib
    from flask import current_app
    secret = current_app.config.get('SECRET_KEY', 'default-key')

    def _is_valid_broadcast_email(email: str) -> bool:
        """Return False for placeholder / ghost addresses that should never receive broadcasts."""
        if not email or '@' not in email:
            return False
        domain = email.rsplit('@', 1)[-1].lower()
        # Reject local / fake domains (e.g. @guest.siiqo.local, @example.com, .local TLD)
        if domain.endswith('.local') or domain in ('example.com', 'test.com', 'localhost'):
            return False
        # Must have at least one dot in the domain (real TLD present)
        if '.' not in domain:
            return False
        return True

    for user in recipients:

        if not _is_valid_broadcast_email(getattr(user, 'email', '')):
            skipped += 1
            continue

        try:
            token = hashlib.sha256(f"{user.email}{secret}".encode()).hexdigest()[:16]
            base_url = request.host_url.rstrip('/')
            unsubscribe_link = f"{base_url}/api/auth/unsubscribe?email={user.email}&token={token}"
            
            ok = send_siiqo_email(
                to_email=user.email,
                subject=subject,
                template_name="broadcast",
                first_name=getattr(user, 'first_name', None) or "Siiqo Member",
                body_content=body,
                unsubscribe_link=None if critical else unsubscribe_link
            )
            if ok:
                sent += 1
            else:
                failed += 1
        except Exception as e:
            failed += 1

    return jsonify({
        "message": "Broadcast dispatched.",
        "details": {
            "audience": target_audience,
            "total_recipients": len(recipients),
            "sent": sent,
            "failed": failed,
            "skipped_invalid": skipped,
        },
    }), 200


# ---------------------------------------------------------------------------
# Subscription Management (Admin)
# ---------------------------------------------------------------------------

@admin_bp.route('/subscriptions', methods=['GET'])
@jwt_required()
def list_subscriptions():
    admin = _get_admin(get_jwt_identity())
    if not admin:
        return jsonify({"message": "Admin access required"}), 403

    subs = VendorSubscription.query.all()
    result = []
    for s in subs:
        vendor = db.session.get(User, s.vendor_id)
        plan = db.session.get(SubscriptionPlan, s.plan_id)
        result.append({
            "id": s.id,
            "vendor_id": s.vendor_id,
            "vendor_email": vendor.email if vendor else "N/A",
            "plan_name": plan.name if plan else "N/A",
            "status": s.status,
            "start_date": s.start_date.isoformat() if s.start_date else None,
            "end_date": s.end_date.isoformat() if s.end_date else None,
        })
    return jsonify({"status": "success", "subscriptions": result}), 200


@admin_bp.route('/subscriptions/<int:vendor_id>/grant', methods=['POST'])
@jwt_required()
def grant_subscription(vendor_id):
    """Manually grant a Pro subscription to a vendor."""
    admin = _require_superadmin(get_jwt_identity())
    if not admin:
        return jsonify({"message": "Superadmin access required"}), 403

    user = db.session.get(User, vendor_id)
    if not user:
        return jsonify({"message": "Vendor not found"}), 404

    data = request.get_json() or {}
    months = int(data.get('months', 1))
    plan_name = data.get('plan_name', 'PRO_MONTHLY')

    plan = SubscriptionPlan.query.filter_by(name=plan_name).first()
    if not plan:
        return jsonify({"message": f"Plan '{plan_name}' not found"}), 404

    existing = VendorSubscription.query.filter_by(vendor_id=user.id, status='ACTIVE').all()
    for sub in existing:
        sub.status = 'SUPERSEDED'

    from dateutil.relativedelta import relativedelta
    now = _utcnow()
    new_sub = VendorSubscription(
        vendor_id=user.id,
        plan_id=plan.id,
        status='ACTIVE',
        start_date=now,
        end_date=now + relativedelta(months=months),
    )
    db.session.add(new_sub)
    db.session.commit()

    return jsonify({"status": "success", "message": f"Granted {months} months of {plan_name} to {user.email}"}), 201


@admin_bp.route('/subscriptions/<int:vendor_id>/revoke', methods=['DELETE'])
@jwt_required()
def revoke_subscription(vendor_id):
    """Manually revoke/cancel a vendor's active subscription."""
    admin = _require_superadmin(get_jwt_identity())
    if not admin:
        return jsonify({"message": "Superadmin access required"}), 403

    VendorSubscription.query.filter_by(
        vendor_id=vendor_id, status='ACTIVE'
    ).update({'status': 'CANCELLED'})
    db.session.commit()

    return jsonify({"status": "success", "message": f"Revoked active subscriptions for vendor {vendor_id}"}), 200


@admin_bp.route('/users/<int:user_id>/adjust-balance', methods=['POST'])
@jwt_required()
def adjust_user_balance(user_id):
    """SuperAdmin manual balance adjustments for referrals or promos."""
    admin = _require_superadmin(get_jwt_identity())
    if not admin:
        return jsonify({"message": "Superadmin access required"}), 403

    user = db.session.get(User, user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    data = request.get_json() or {}
    amount = float(data.get('amount', 0))
    action = data.get('action', 'CREDIT').strip().upper()
    description = (data.get('description') or '').strip()

    if amount <= 0:
        return jsonify({"message": "Amount must be greater than 0"}), 400

    if action not in ('CREDIT', 'DEBIT'):
        return jsonify({"message": "Action must be CREDIT or DEBIT"}), 400

    from app.models.finance import Ledger
    from app.models.communication import Notification
    from sqlalchemy import func
    import uuid

    # Calculate balance after
    credits = db.session.query(func.sum(Ledger.amount)).filter_by(
        vendor_id=user.id, transaction_type='CREDIT'
    ).scalar() or 0
    debits = db.session.query(func.sum(Ledger.amount)).filter_by(
        vendor_id=user.id, transaction_type='DEBIT'
    ).scalar() or 0

    current_balance = float(credits) - float(debits)
    if action == 'CREDIT':
        balance_after = current_balance + amount
    else:
        balance_after = current_balance - amount

    ledger_entry = Ledger(
        vendor_id=user.id,
        transaction_type=action,
        amount=amount,
        description=description or f"Manual balance adjustment by admin",
        reference_id=f"MANUAL-{uuid.uuid4().hex[:8].upper()}",
        balance_after=balance_after,
    )
    db.session.add(ledger_entry)

    # Notify user
    notification = Notification(
        user_id=user.id,
        title="Wallet Balance Adjusted",
        message=f"Admin has {'credited' if action == 'CREDIT' else 'debited'} your wallet with ₦{amount:,.2f}. Reason: {description or 'Manual balance adjustment.'}",
        type="SYSTEM"
    )
    db.session.add(notification)
    
    db.session.commit()

    return jsonify({
        "status": "success",
        "message": f"Successfully {action}ed ₦{amount:,.2f} to user {user.email}",
        "new_balance": balance_after
    }), 200



# ---------------------------------------------------------------------------
# GET  /admin/payout/vendor-accounts
# POST /admin/payout/fix-bank-code
# POST /admin/payout/retry-order/<order_id>
# POST /admin/payout/retry-all-failed
#
# These routes let admin inspect vendor bank data and retry failed payouts
# without needing direct DB access from CloudShell.
# ---------------------------------------------------------------------------

@admin_bp.route('/payout/vendor-accounts', methods=['GET'])
@jwt_required()
def admin_list_vendor_bank_accounts():
    """
    List all vendor bank accounts — shows bank_code, account_number,
    is_default, is_verified. Use to spot wrong bank codes before they
    cause payout failures.
    """
    from app.models.withdrawal import VendorBankAccount
    admin_id = get_jwt_identity()
    if not _get_admin(_parse_admin_id(admin_id)):
        return jsonify({"message": "Unauthorized"}), 403

    accounts = (
        db.session.query(VendorBankAccount, User)
        .join(User, User.id == VendorBankAccount.vendor_id)
        .order_by(VendorBankAccount.created_at.desc())
        .all()
    )

    return jsonify({
        "accounts": [
            {
                "id": acc.id,
                "vendor_id": acc.vendor_id,
                "vendor_email": user.email,
                "bank_name": acc.bank_name,
                "bank_code": acc.bank_code,
                "account_number": acc.account_number,
                "account_name": acc.account_name,
                "is_default": acc.is_default,
                "is_verified": acc.is_verified,
                "recipient_code": acc.recipient_code,
                "created_at": acc.created_at.isoformat() if acc.created_at else None,
            }
            for acc, user in accounts
        ],
        "count": len(accounts),
    }), 200


@admin_bp.route('/payout/fix-bank-code', methods=['POST'])
@jwt_required()
def admin_fix_bank_code():
    """
    Fix a vendor's stored bank_code and/or bank_name.
    Use when the wrong code is stored (e.g. OPay 999992 → 100004).

    Body: { account_number, bank_code, bank_name (optional) }
    Updates ALL rows matching account_number.
    """
    from app.models.withdrawal import VendorBankAccount
    admin_id = get_jwt_identity()
    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    data = request.get_json() or {}
    account_number = (data.get("account_number") or "").strip()
    new_bank_code = (data.get("bank_code") or "").strip()
    new_bank_name = (data.get("bank_name") or "").strip()

    if not account_number or not new_bank_code:
        return jsonify({"message": "account_number and bank_code are required"}), 400

    accounts = VendorBankAccount.query.filter_by(account_number=account_number).all()
    if not accounts:
        return jsonify({"message": f"No bank accounts found with account_number {account_number}"}), 404

    updated = []
    for acc in accounts:
        old_code = acc.bank_code
        old_name = acc.bank_name
        acc.bank_code = new_bank_code
        if new_bank_name:
            acc.bank_name = new_bank_name
        updated.append({
            "id": acc.id,
            "vendor_id": acc.vendor_id,
            "account_number": acc.account_number,
            "old_bank_code": old_code,
            "new_bank_code": new_bank_code,
            "old_bank_name": old_name,
            "new_bank_name": new_bank_name or old_name,
        })

    db.session.commit()
    logging.info("[ADMIN PAYOUT] Fixed bank code for account %s: %s → %s (%d rows)",
                 account_number, accounts[0].bank_code, new_bank_code, len(updated))

    return jsonify({
        "message": f"Bank code updated for {len(updated)} account(s)",
        "updated": updated,
    }), 200


@admin_bp.route('/payout/retry-order/<int:order_id>', methods=['POST'])
@jwt_required()
def admin_retry_payout(order_id):
    """
    Retry the Daya vendor payout for a specific order.
    Use when automatic payout failed (INTEGRATION_FAILED, wrong bank code, etc.)

    The order must be COMPLETED/PAID status with a CRYPTO payment method.
    Funds must already be in Daya withdrawal balance.

    Optional body: { amount_ngn: float } to override the payout amount.
    """
    from app.models.order import Order
    from app.models.escrow import EscrowTransaction
    from app.models.withdrawal import VendorBankAccount
    from app.services import daya_service
    import uuid

    admin_id = get_jwt_identity()
    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    order = db.session.get(Order, order_id)
    if not order:
        return jsonify({"message": f"Order #{order_id} not found"}), 404

    escrow = EscrowTransaction.query.filter_by(order_id=order_id).first()
    if not escrow:
        return jsonify({"message": f"No escrow record for Order #{order_id}"}), 404

    data = request.get_json() or {}
    override_amount = data.get("amount_ngn")

    # Calculate payout amount
    if override_amount:
        net_amount_ngn = float(override_amount)
    else:
        net_amount_ngn = float(escrow.amount) - float(escrow.fee_amount or 0)

    # Get vendor's current default bank account
    bank_acc = VendorBankAccount.query.filter_by(
        vendor_id=order.vendor_id, is_default=True
    ).first() or VendorBankAccount.query.filter_by(
        vendor_id=order.vendor_id
    ).first()

    if not bank_acc:
        return jsonify({
            "message": f"Vendor {order.vendor_id} has no bank account registered",
            "vendor_id": order.vendor_id,
        }), 400

    # Step 1: Ensure enough in withdrawal balance
    balance_info = {}
    try:
        balance = daya_service.get_merchant_balance()
        bal_data = balance.get("data", {})
        collection_usd = float(bal_data.get("collection_balance_usd", 0))
        withdrawal_usd = float(bal_data.get("withdrawal_balance_usd", 0))
        balance_info = {"collection_usd": collection_usd, "withdrawal_usd": withdrawal_usd}

        estimated_usd_needed = round((net_amount_ngn / 1380) * 1.02, 4)
        if withdrawal_usd < estimated_usd_needed:
            shortfall = estimated_usd_needed - withdrawal_usd
            amount_to_move = min(round(shortfall + 0.10, 4), collection_usd)
            if amount_to_move > 0:
                idem = f"admin-bal-transfer-{order_id}-{uuid.uuid4().hex[:8]}"
                daya_service.transfer_collection_to_withdrawal(
                    amount_usd=amount_to_move,
                    idempotency_key=idem,
                )
                balance_info["moved_usd"] = amount_to_move
    except Exception as exc:
        balance_info["balance_error"] = str(exc)

    # Step 2: Attempt the NGN transfer with account_name to bypass Daya resolution
    payout_ref = f"ADMIN-RETRY-{order_id}-{uuid.uuid4().hex[:8].upper()}"
    result = daya_service.transfer_ngn_to_vendor(
        amount_ngn=net_amount_ngn,
        bank_code=bank_acc.bank_code,
        account_number=bank_acc.account_number,
        account_name=bank_acc.account_name or "",
        reference=payout_ref,
        order_id=order_id,
    )

    if result.get("success"):
        # Add notification to vendor
        db.session.add(Notification(
            user_id=order.vendor_id,
            title="Payment On Its Way",
            message=(
                f"Order #{order_id} payout has been processed. "
                f"NGN{net_amount_ngn:,.2f} is being transferred to your bank account "
                f"({bank_acc.bank_name} ···{bank_acc.account_number[-4:]})."
            ),
            type="ESCROW",
            order_id=order_id,
        ))
        db.session.commit()
        logging.info("[ADMIN PAYOUT] Retry succeeded for Order #%s: NGN%.2f → %s/%s ref=%s",
                     order_id, net_amount_ngn, bank_acc.bank_code, bank_acc.account_number, payout_ref)
        return jsonify({
            "message": f"Payout initiated successfully for Order #{order_id}",
            "amount_ngn": net_amount_ngn,
            "bank_code": bank_acc.bank_code,
            "account_number": bank_acc.account_number,
            "account_name": bank_acc.account_name,
            "reference": payout_ref,
            "balance_info": balance_info,
        }), 200
    else:
        logging.error("[ADMIN PAYOUT] Retry FAILED for Order #%s: %s",
                      order_id, result.get("error_message"))
        return jsonify({
            "message": f"Payout failed for Order #{order_id}",
            "error": result.get("error_message"),
            "bank_code_used": bank_acc.bank_code,
            "account_number_used": bank_acc.account_number,
            "account_name_used": bank_acc.account_name,
            "reference": payout_ref,
            "balance_info": balance_info,
            "hint": "If error is INTEGRATION_FAILED, the bank_code may still be wrong. "
                    "Use POST /admin/payout/fix-bank-code first, then retry.",
        }), 502


@admin_bp.route('/payout/retry-all-failed', methods=['POST'])
@admin_bp.route('/payout/retry-daya', methods=['POST'])
@jwt_required()
def admin_retry_all_failed_payouts():
    """
    Scan all COMPLETED crypto orders where vendor hasn't been paid
    (escrow is RELEASED but no successful Daya transfer logged) and retry each.

    This is the 'fix it once and for all' route — run it after fixing bank codes
    and it will sweep through every unpaid order automatically.
    """
    from app.models.order import Order
    from app.models.escrow import EscrowTransaction
    from app.models.withdrawal import VendorBankAccount, DayaPayment
    from app.services import daya_service
    import uuid

    admin_id = get_jwt_identity()
    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    # Find all crypto orders that are COMPLETED/PAID but whose escrow is
    # RELEASED (meaning we already confirmed payment) — these are candidates
    # for a vendor payout retry.
    # We use a dry-run flag to preview without actually sending.
    dry_run = request.get_json().get("dry_run", False) if request.get_json() else False

    DAYA_PAYMENT_METHODS = ('CRYPTO', 'DAYA', 'USDT', 'USDC', 'DAYA_BANK_TRANSFER')

    # Find all completed orders paid via Daya
    completed_daya_orders = (
        db.session.query(Order, EscrowTransaction)
        .join(EscrowTransaction, EscrowTransaction.order_id == Order.id)
        .filter(
            Order.payment_method.in_(DAYA_PAYMENT_METHODS),
            Order.status.in_(["COMPLETED", "PAID"]),
        )
        .all()
    )

    # Also catch orders whose escrow txn starts with DYA- or DAYA-
    daya_escrow_orders = (
        db.session.query(Order, EscrowTransaction)
        .join(EscrowTransaction, EscrowTransaction.order_id == Order.id)
        .filter(
            Order.payment_method.notin_(DAYA_PAYMENT_METHODS),
            Order.status.in_(["COMPLETED", "PAID"]),
            (
                EscrowTransaction.transaction_number.like('DYA-%') |
                EscrowTransaction.payscrow_transaction_id.like('DAYA-%')
            ),
        )
        .all()
    )

    all_candidates = {o.id: (o, e) for o, e in (completed_daya_orders + daya_escrow_orders)}

    results = []
    for order_id, (order, escrow) in sorted(all_candidates.items()):
        bank_acc = VendorBankAccount.query.filter_by(
            vendor_id=order.vendor_id, is_default=True
        ).first() or VendorBankAccount.query.filter_by(
            vendor_id=order.vendor_id
        ).first()

        net_amount_ngn = float(escrow.amount) - float(escrow.fee_amount or 0)

        entry = {
            "order_id": order.id,
            "vendor_id": order.vendor_id,
            "payment_method": order.payment_method,
            "amount_ngn": net_amount_ngn,
            "bank_code": bank_acc.bank_code if bank_acc else None,
            "account_number": bank_acc.account_number if bank_acc else None,
            "account_name": bank_acc.account_name if bank_acc else None,
            "bank_name": bank_acc.bank_name if bank_acc else None,
            "status": None,
            "error": None,
            "reference": None,
        }

        if not bank_acc:
            entry["status"] = "SKIPPED"
            entry["error"] = "No bank account registered for vendor"
            results.append(entry)
            continue

        if dry_run:
            entry["status"] = "DRY_RUN"
            results.append(entry)
            continue

        # Ensure ledger credit exists (idempotent)
        ledger_credit = Ledger.query.filter_by(
            vendor_id=order.vendor_id,
            transaction_type='CREDIT',
        ).filter(
            Ledger.reference_id.in_([
                escrow.transaction_number or '',
                f"ORD-{order.id}",
            ])
        ).first()

        if not ledger_credit:
            from app.routes.escrow import _credit_vendor_ledger
            _credit_vendor_ledger(
                vendor_id=order.vendor_id,
                amount=net_amount_ngn,
                reference_id=escrow.transaction_number or f"ORD-{order.id}",
                description=f"Backfill payout credit for Order #{order.id}",
            )
            db.session.flush()

        # Attempt payout via Daya
        try:
            from app.routes.payments import _payout_vendor_via_daya
            _payout_vendor_via_daya(order, escrow)
            entry["status"] = "SUCCESS"
        except Exception as exc:
            db.session.rollback()
            entry["status"] = "FAILED"
            entry["error"] = str(exc)

        results.append(entry)

    if not dry_run:
        db.session.commit()

    success_count = sum(1 for r in results if r["status"] == "SUCCESS")
    failed_count = sum(1 for r in results if r["status"] in ("FAILED", "ERROR"))
    skipped_count = sum(1 for r in results if r["status"] == "SKIPPED")

    return jsonify({
        "dry_run": dry_run,
        "total_orders_checked": len(results),
        "success": success_count,
        "failed": failed_count,
        "skipped": skipped_count,
        "results": results,
    }), 200


# ---------------------------------------------------------------------------
# POST /admin/data/wipe-transactions
#
# Wipes all test transaction data — orders, escrow, daya_payments, ledger,
# receipts, notifications linked to orders — while preserving users,
# products, storefronts, and bank accounts.
#
# SUPERADMIN only. Requires { "confirm": "WIPE_ALL_TRANSACTIONS" } in body
# as a safety check so it can't be triggered accidentally.
# ---------------------------------------------------------------------------

@admin_bp.route('/data/wipe-transactions', methods=['POST'])
@jwt_required()
def admin_wipe_transactions():
    """
    Wipe all test transaction data cleanly.
    Preserves: users, products, storefronts, bank accounts, blog, categories.
    Deletes: orders, order_items, escrow_transactions, daya_payments,
             ledger entries, receipts, order-linked notifications.

    Body must include: { "confirm": "WIPE_ALL_TRANSACTIONS" }
    """
    admin_id = get_jwt_identity()
    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    data = request.get_json() or {}
    if data.get("confirm") != "WIPE_ALL_TRANSACTIONS":
        return jsonify({
            "message": "Safety check failed. Send { \"confirm\": \"WIPE_ALL_TRANSACTIONS\" } to proceed.",
            "hint": "This deletes ALL orders, escrow records, daya payments, ledger entries and notifications.",
        }), 400

    from app.models.order import Order, OrderItem
    from app.models.escrow import EscrowTransaction
    from app.models.withdrawal import DayaPayment
    from app.models.finance import Ledger, Receipt
    from app.models.communication import Notification
    from sqlalchemy import text

    counts = {}

    try:
        # Delete in dependency order — children before parents to avoid FK violations

        # 1. Notifications and messages linked to orders
        notif_result = db.session.execute(
            text("DELETE FROM notifications WHERE order_id IS NOT NULL")
        )
        counts["notifications"] = notif_result.rowcount

        msg_result = db.session.execute(
            text("DELETE FROM messages WHERE order_id IS NOT NULL")
        )
        counts["messages"] = msg_result.rowcount

        # 2. Ledger entries
        ledger_result = db.session.execute(text("DELETE FROM ledgers"))
        counts["ledger_entries"] = ledger_result.rowcount

        # 3. Invoices (references orders)
        invoice_result = db.session.execute(text("DELETE FROM invoices"))
        counts["invoices"] = invoice_result.rowcount

        # 4. Receipts (references orders)
        receipt_result = db.session.execute(text("DELETE FROM receipts"))
        counts["receipts"] = receipt_result.rowcount

        # 5. Reviews (references orders)
        try:
            review_result = db.session.execute(
                text("DELETE FROM reviews WHERE order_id IS NOT NULL")
            )
            counts["reviews"] = review_result.rowcount
        except Exception:
            counts["reviews"] = 0  # table may not exist yet

        # 6. Daya payments (references orders)
        daya_result = db.session.execute(text("DELETE FROM daya_payments"))
        counts["daya_payments"] = daya_result.rowcount

        # 7. POD payments (references orders)
        try:
            pod_result = db.session.execute(text("DELETE FROM pod_payments"))
            counts["pod_payments"] = pod_result.rowcount
        except Exception:
            counts["pod_payments"] = 0

        # 8. Logistics assignments (references orders)
        try:
            la_result = db.session.execute(text("DELETE FROM logistics_assignments"))
            counts["logistics_assignments"] = la_result.rowcount
        except Exception:
            counts["logistics_assignments"] = 0

        # 9. Escrow transactions (references orders)
        escrow_result = db.session.execute(text("DELETE FROM escrow_transactions"))
        counts["escrow_transactions"] = escrow_result.rowcount

        # 10. Order items (references orders)
        items_result = db.session.execute(text("DELETE FROM order_items"))
        counts["order_items"] = items_result.rowcount

        # 11. Orders — everything that references them is now gone
        orders_result = db.session.execute(text("DELETE FROM orders"))
        counts["orders"] = orders_result.rowcount

        db.session.commit()

        logging.warning(
            "[ADMIN WIPE] SuperAdmin %s wiped all transactions. Counts: %s",
            admin_id, counts
        )

        return jsonify({
            "message": "All transaction data wiped successfully. Ready for fresh testing.",
            "deleted": counts,
            "preserved": [
                "users", "products", "storefronts", "vendor_bank_accounts",
                "vendor_crypto_wallets", "categories", "blog_articles",
                "cart_items", "platform_settings",
            ],
        }), 200

    except Exception as exc:
        db.session.rollback()
        logging.error("[ADMIN WIPE] Failed: %s", exc)
        return jsonify({"message": f"Wipe failed: {str(exc)}"}), 500


# ---------------------------------------------------------------------------
# POST /admin/storefronts/<int:storefront_id>/verify-pro
# ---------------------------------------------------------------------------

@admin_bp.route('/storefronts/<int:storefront_id>/verify-pro', methods=['POST'])
@jwt_required()
def admin_verify_pro_storefront(storefront_id):
    admin_id = get_jwt_identity()
    admin = _get_admin(admin_id)
    if not admin:
        return jsonify({"message": "Admin authorization required"}), 403

    sf = db.session.get(Storefront, storefront_id)
    if not sf:
        return jsonify({"message": "Storefront not found"}), 404

    from datetime import timedelta
    sf.is_pro_verified = True
    sf.pro_verified_expires_at = _utcnow() + timedelta(days=365)
    sf.verification_status = 'APPROVED'
    sf.is_verified = True

    db.session.add(Notification(
        user_id=sf.vendor_id,
        title="Pro Verified Status Activated! ⭐",
        message="Congratulations! Your NIN & CAC verification has been approved. You now enjoy Pro Verified Gold status and a reduced 5.4% platform fee.",
        type="SYSTEM"
    ))

    db.session.commit()
    return jsonify({
        "status": "success",
        "message": f"Storefront #{sf.id} '{sf.store_name}' is now Pro Verified until {sf.pro_verified_expires_at.strftime('%Y-%m-%d')}.",
        "storefront": sf.to_public_dict()
    }), 200


# ---------------------------------------------------------------------------
# POST /admin/storefronts/publish-all-approved
# One-time action: publish + grant Pro Verified to all admin-approved storefronts.
# Use this to activate all founding vendors at once.
# ---------------------------------------------------------------------------

@admin_bp.route('/storefronts/publish-all-approved', methods=['POST'])
@jwt_required()
def publish_all_approved_storefronts():
    """
    Bulk-activates all admin-approved storefronts that are not yet published.
    For each storefront where is_verified=True:
      - Sets is_published = True (makes store live on marketplace)
      - Sets is_pro_verified = True (grants Pro Verified badge)
      - Sets pro_verified_expires_at = now + 1 year
      - Sends a founder notification email + in-app notification

    Safe to call multiple times — already-published stores are skipped.
    SuperAdmin only.
    """
    admin_id = get_jwt_identity()
    if not _require_superadmin(_parse_admin_id(admin_id)):
        return jsonify({"message": "SuperAdmin required"}), 403

    from datetime import datetime as _dt, timedelta as _td, timezone as _tz
    from app.models.communication import Notification as _Notif
    from app.utils.email import send_siiqo_email

    now = _dt.now(_tz.utc)
    pro_expiry = now + _td(days=365)

    # Find all admin-approved storefronts
    approved = Storefront.query.filter_by(is_verified=True).all()

    published_count = 0
    already_live_count = 0
    email_sent_count = 0
    errors = []

    for sf in approved:
        vendor = sf.vendor
        if not vendor:
            continue

        was_already_live = sf.is_published

        # Publish the store
        sf.is_published = True

        # Grant Pro Verified if not already active
        if not sf.is_pro_verified or not sf.pro_verified_expires_at or sf.pro_verified_expires_at < now:
            sf.is_pro_verified = True
            sf.pro_verified_expires_at = pro_expiry

        if not was_already_live:
            published_count += 1
            # Send in-app notification
            db.session.add(_Notif(
                user_id=vendor.id,
                title="🎉 Your store is now LIVE!",
                message=(
                    f"Congratulations, {vendor.first_name or 'Vendor'}! "
                    f"Your store '{sf.store_name}' is now live on Siiqo. "
                    "As a founding vendor, you also have Pro Verified access for 1 year — at no charge."
                ),
                type="ACCOUNT",
            ))
            # Send email
            try:
                store_url = f"https://siiqo.com/{sf.store_slug}"
                send_siiqo_email(
                    to_email=vendor.email,
                    subject="🎉 Your Siiqo Store Is Now Live — Founding Vendor Access",
                    template_name="founder_store_live",
                    first_name=vendor.first_name or "Vendor",
                    store_name=sf.store_name,
                    store_url=store_url,
                )
                email_sent_count += 1
            except Exception as e:
                errors.append(f"Email failed for {vendor.email}: {str(e)}")
                logging.warning(f"[BULK PUBLISH] Email failed for storefront #{sf.id}: {e}")
        else:
            already_live_count += 1
            # Still grant Pro Verified if they didn't have it
            if not was_already_live:
                pass  # notification already sent above
            else:
                # Grant Pro Verified silently if missing
                pass

    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Database error: {str(e)}"}), 500

    logging.info(
        f"[BULK PUBLISH] Admin {admin_id} activated founders: "
        f"published={published_count}, already_live={already_live_count}, "
        f"emails_sent={email_sent_count}, errors={len(errors)}"
    )

    return jsonify({
        "status": "success",
        "summary": {
            "total_approved_storefronts": len(approved),
            "newly_published": published_count,
            "already_live": already_live_count,
            "emails_sent": email_sent_count,
            "errors": errors,
        },
        "message": (
            f"Done. {published_count} store(s) newly published and notified. "
            f"{already_live_count} were already live. "
            f"All approved vendors now have Pro Verified access for 1 year."
        ),
    }), 200


# ---------------------------------------------------------------------------
# ONE-TIME MIGRATION ENDPOINT (TEMPORARY - Remove after running)
# ---------------------------------------------------------------------------

@admin_bp.route('/run-grants-migration', methods=['POST'])
@jwt_required()
@limiter.limit("1 per hour")
def run_grants_migration_once():
    """
    ONE-TIME USE ONLY: Run grants table migration
    This endpoint should be removed after successful migration
    """
    admin_id = get_jwt_identity()
    admin = _require_superadmin(_parse_admin_id(admin_id))
    if not admin:
        return jsonify({"message": "SuperAdmin required"}), 403
    
    try:
        from sqlalchemy import text
        
        # Read SQL migration file
        sql_file = 'migrations/create_grants_table.sql'
        logging.info(f"[MIGRATION] Reading {sql_file}")
        
        with open(sql_file, 'r', encoding='utf-8') as f:
            sql_content = f.read()
        
        # Execute migration
        logging.info("[MIGRATION] Executing grants table creation...")
        db.session.execute(text(sql_content))
        db.session.commit()
        
        # Verify
        result = db.session.execute(text("""
            SELECT COUNT(*) as total,
                   COUNT(*) FILTER (WHERE status = 'open') as open,
                   COUNT(*) FILTER (WHERE featured = TRUE) as featured
            FROM grants
        """))
        
        row = result.fetchone()
        
        # Audit log
        AdminAuditLog.log_action(
            admin=admin,
            action='DATABASE_MIGRATION',
            resource_type='Grant',
            resource_id=0,
            details={
                'migration': 'create_grants_table',
                'total_grants': row[0],
                'open_grants': row[1],
                'featured_grants': row[2]
            }
        )
        
        logging.info(f"[MIGRATION SUCCESS] Grants table created with {row[0]} initial records")
        
        return jsonify({
            'message': 'Grants table migration completed successfully',
            'grants_created': row[0],
            'open_grants': row[1],
            'featured_grants': row[2],
            'warning': 'Please remove this endpoint from production code'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"[MIGRATION ERROR] {str(e)}")
        return jsonify({
            'message': 'Migration failed',
            'error': str(e),
            'troubleshooting': [
                'Check if grants table already exists',
                'Verify admin_users table exists (foreign key dependency)',
                'Check PostgreSQL logs for details'
            ]
        }), 500


# ---------------------------------------------------------------------------
# PUBLIC TEST ENDPOINT FOR GRANTS MIGRATION (NO AUTH - REMOVE AFTER USE!)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# POST /admin/delete-bot-accounts — Delete fake bot accounts
# ---------------------------------------------------------------------------

@admin_bp.route('/delete-bot-accounts', methods=['POST'])
@jwt_required()
@limiter.limit("5 per hour")
def delete_bot_accounts():
    """
    Delete bot accounts from the database.
    
    Bot detection criteria:
    - First/last name matches pattern: Dv7284677, Pr4695973, Ol2449129
    - Email domain: @siiqo.app (internal domain)
    
    POST /api/admin/delete-bot-accounts
    Body: { "confirm": true }  # Safety confirmation
    
    Returns:
        - List of deleted accounts
        - Count of deletions
    """
    import re
    
    admin_id = get_jwt_identity()
    admin = _get_admin(admin_id)
    
    if not admin:
        return jsonify({"message": "Unauthorized"}), 401
    
    data = request.get_json() or {}
    confirm = data.get('confirm', False)
    
    # Bot detection patterns
    BOT_PATTERNS = [
        r'^[A-Z][a-z]\d{6,8}$',  # Dv7284677, Pr4695973
        r'^[A-Z]{2}\d{7,9}$',    # Ol2449129
    ]
    
    try:
        # Find bot accounts
        users = User.query.filter(User.email.like('%@siiqo.app')).all()
        
        bot_accounts = []
        for user in users:
            is_bot = False
            
            # Check if name matches bot pattern
            for pattern in BOT_PATTERNS:
                if (user.first_name and re.match(pattern, user.first_name)) or \
                   (user.last_name and re.match(pattern, user.last_name)):
                    is_bot = True
                    break
            
            if is_bot:
                bot_accounts.append({
                    'id': user.id,
                    'email': user.email,
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'created_at': user.created_at.isoformat() if user.created_at else None,
                })
        
        if not confirm:
            # Preview mode - just show what would be deleted
            return jsonify({
                "message": f"Found {len(bot_accounts)} bot accounts",
                "bot_accounts": bot_accounts[:50],  # Show first 50
                "total_found": len(bot_accounts),
                "note": "Set 'confirm: true' to delete these accounts"
            }), 200
        
        # Confirmation received - delete bot accounts
        deleted_ids = []
        for bot in bot_accounts:
            user_id = bot['id']
            user = db.session.get(User, user_id)
            
            if user:
                # Delete related data first
                # Delete referrals
                from app.models.partnerships import Referral
                Referral.query.filter(
                    (Referral.referrer_id == user_id) | (Referral.referred_id == user_id)
                ).delete()
                
                # Delete notifications
                Notification.query.filter_by(user_id=user_id).delete()
                
                # Delete the user
                db.session.delete(user)
                deleted_ids.append(user_id)
        
        db.session.commit()
        
        # Log the action
        logging.info(
            f"[ADMIN] {admin.email} deleted {len(deleted_ids)} bot accounts | "
            f"IDs: {deleted_ids[:10]}{'...' if len(deleted_ids) > 10 else ''}"
        )
        
        # Create audit log
        db.session.add(AdminAuditLog(
            admin_id=admin.id,
            action='DELETE_BOT_ACCOUNTS',
            details=f"Deleted {len(deleted_ids)} bot accounts",
            ip_address=request.remote_addr,
        ))
        db.session.commit()
        
        return jsonify({
            "message": f"Successfully deleted {len(deleted_ids)} bot accounts",
            "deleted_count": len(deleted_ids),
            "deleted_accounts": bot_accounts[:20],  # Show first 20 deleted
        }), 200
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"[ADMIN] Error deleting bot accounts: {e}")
        return jsonify({"message": f"Error deleting bot accounts: {str(e)}"}), 500


# ---------------------------------------------------------------------------
# ADMIN EVENTS ENDPOINTS
# ---------------------------------------------------------------------------

@admin_bp.route('/events', methods=['GET'])
@jwt_required()
def admin_list_events():
    """
    Admin-only: list ALL events across all vendors with ticket stats
    and collect all pending manual-payment tickets.
    """
    try:
        admin_id = _parse_admin_id(get_jwt_identity())
        if not _get_admin(admin_id):
            return jsonify({"message": "Admin access required"}), 403

        from app.models.event import Event, TicketPurchase
        from app.models.user import User, Storefront

        events_q = Event.query.filter_by(is_deleted=False)\
            .order_by(Event.created_at.desc()).all()

        events_data = []
        all_pending = []

        for ev in events_q:
            # Vendor name lookup
            vendor = db.session.get(User, ev.vendor_id)
            vendor_name = None
            if vendor:
                sf = vendor.storefront
                vendor_name = (sf.store_name if sf else None) or vendor.business_name or vendor.email

            # Ticket statistics
            purchases = TicketPurchase.query.filter_by(event_id=ev.id).all()
            tickets_sold   = len([p for p in purchases if p.status == 'ACTIVE'])
            revenue        = sum(float(p.price_paid or 0) for p in purchases if p.status == 'ACTIVE')
            pending_manual = [p for p in purchases if getattr(p, 'manual_payment_status', None) == 'PENDING']

            # Collect pending tickets with event title
            for pm in pending_manual:
                d = pm.to_dict()
                d['event_title'] = ev.title
                all_pending.append(d)

            events_data.append({
                'id':                   ev.id,
                'title':                ev.title,
                'slug':                 ev.slug,
                'vendor_id':            ev.vendor_id,
                'vendor_name':          vendor_name,
                'event_format':         ev.event_format or 'in-person',
                'event_type':           ev.event_type or '',
                'start_date':           ev.start_date.isoformat() if ev.start_date else None,
                'is_published':         ev.is_published,
                'is_deleted':           ev.is_deleted,
                'tickets_sold':         tickets_sold,
                'total_capacity':       ev.total_capacity,
                'revenue':              revenue,
                'registration_type':    ev.registration_type or 'native',
                'pending_manual_count': len(pending_manual),
            })

        return jsonify({
            'events':                 events_data,
            'pending_manual_tickets': all_pending,
        }), 200

    except Exception as e:
        logging.error(f"[ADMIN] Error listing events: {e}")
        return jsonify({'message': 'Failed to list events'}), 500


@admin_bp.route('/events/<int:event_id>/tickets/<int:ticket_id>/confirm-manual', methods=['POST'])
@jwt_required()
def admin_confirm_manual_payment(event_id, ticket_id):
    """Admin confirms a manual payment — delegates to the same logic as vendor."""
    try:
        admin_id = _parse_admin_id(get_jwt_identity())
        if not _get_admin(admin_id):
            return jsonify({"message": "Admin access required"}), 403

        from app.models.event import Event, TicketPurchase
        from app.utils.email import send_siiqo_email

        ticket = TicketPurchase.query.filter_by(id=ticket_id, event_id=event_id).first()
        if not ticket:
            return jsonify({'message': 'Ticket not found'}), 404
        if getattr(ticket, 'manual_payment_status', None) != 'PENDING':
            return jsonify({'message': f'Ticket is already {ticket.manual_payment_status}'}), 400

        ticket.status = 'ACTIVE'
        ticket.manual_payment_status = 'APPROVED'
        ticket.confirmed_by = None  # Admin has no vendor user ID
        ticket.confirmed_at = datetime.now(timezone.utc)
        ticket.expires_at = None

        event = ticket.event
        if ticket.ticket_type:
            ticket.ticket_type.quantity_sold = (ticket.ticket_type.quantity_sold or 0) + 1
        if event:
            event.tickets_sold = (event.tickets_sold or 0) + 1

        db.session.commit()

        # Send confirmation email
        try:
            if event:
                send_siiqo_email(
                    to_email=ticket.buyer_email,
                    subject=f"🎟️ Payment Confirmed — Your Ticket for {event.title}",
                    template_name="ticket_issued",
                    buyer_name=ticket.buyer_name,
                    event_title=event.title,
                    ticket_type_name=ticket.ticket_type.name if ticket.ticket_type else 'Ticket',
                    ticket_code=ticket.ticket_code,
                    quantity=ticket.quantity or 1,
                    event_date=event.start_date.strftime('%A, %B %d, %Y') if event.start_date else 'TBA',
                    event_time=event.start_date.strftime('%I:%M %p') if event.start_date else 'TBA',
                    event_location=event.venue_address or event.city or '',
                    event_format=event.event_format or 'in-person',
                    total_price=f"{float(ticket.price_paid):,.0f}",
                    is_free=False,
                    tickets_url='https://siiqo.com/buyer/tickets',
                    year=datetime.now(timezone.utc).year,
                )
        except Exception as email_err:
            logging.warning(f"Admin confirm email failed (non-fatal): {email_err}")

        return jsonify({'message': 'Payment confirmed. Ticket activated.', 'ticket': ticket.to_dict()}), 200

    except Exception as e:
        db.session.rollback()
        logging.error(f"[ADMIN] Error confirming manual payment: {e}")
        return jsonify({'message': 'Failed to confirm payment'}), 500


@admin_bp.route('/events/<int:event_id>/tickets/<int:ticket_id>/reject-manual', methods=['POST'])
@jwt_required()
def admin_reject_manual_payment(event_id, ticket_id):
    """Admin rejects a manual payment."""
    try:
        admin_id = _parse_admin_id(get_jwt_identity())
        if not _get_admin(admin_id):
            return jsonify({"message": "Admin access required"}), 403

        from app.models.event import Event, TicketPurchase
        from app.utils.email import send_siiqo_email

        ticket = TicketPurchase.query.filter_by(id=ticket_id, event_id=event_id).first()
        if not ticket:
            return jsonify({'message': 'Ticket not found'}), 404
        if getattr(ticket, 'manual_payment_status', None) != 'PENDING':
            return jsonify({'message': f'Ticket is already {ticket.manual_payment_status}'}), 400

        data   = request.get_json() or {}
        reason = data.get('reason', '').strip() or 'Payment could not be verified.'

        ticket.status                = 'CANCELLED'
        ticket.manual_payment_status = 'REJECTED'
        ticket.rejection_reason      = reason
        ticket.confirmed_at          = datetime.now(timezone.utc)

        db.session.commit()

        # Send rejection email
        try:
            event = ticket.event
            if event:
                send_siiqo_email(
                    to_email=ticket.buyer_email,
                    subject=f"❌ Payment Not Verified — {event.title}",
                    template_name="manual_payment_rejected_buyer",
                    buyer_name=ticket.buyer_name,
                    event_title=event.title,
                    rejection_reason=reason,
                    resubmit_url=f"https://siiqo.com/marketplace/events/{event.slug}",
                    organizer_email=event.contact_email or 'support@siiqo.com',
                    year=datetime.now(timezone.utc).year,
                )
        except Exception as email_err:
            logging.warning(f"Admin reject email failed (non-fatal): {email_err}")

        return jsonify({'message': 'Payment rejected. Buyer notified.'}), 200

    except Exception as e:
        db.session.rollback()
        logging.error(f"[ADMIN] Error rejecting manual payment: {e}")
        return jsonify({'message': 'Failed to reject payment'}), 500


# ---------------------------------------------------------------------------
# ADMIN STOREFRONT DETAIL — vendor analytics on click
# ---------------------------------------------------------------------------

@admin_bp.route('/storefronts/<int:storefront_id>/detail', methods=['GET'])
@jwt_required()
def admin_storefront_detail(storefront_id):
    """
    Admin: full vendor analytics for a single storefront.
    Returns product stats, order stats, revenue, event stats, trust tier.
    """
    try:
        admin_id = _parse_admin_id(get_jwt_identity())
        if not _get_admin(admin_id):
            return jsonify({"message": "Admin access required"}), 403

        from app.models.order import Order, OrderItem
        from app.models.product import Product
        from app.models.event import Event, TicketPurchase
        from app.models.trust import VendorTrustProfile
        from sqlalchemy import func

        sf = db.session.get(Storefront, storefront_id)
        if not sf:
            return jsonify({"message": "Storefront not found"}), 404

        vendor = db.session.get(User, sf.vendor_id)

        # ── Product stats ─────────────────────────────────────────────────
        all_products = Product.query.filter_by(storefront_id=sf.id).all()
        active_products = [p for p in all_products if p.is_active]
        total_product_value = sum(float(p.price or 0) * (p.stock_quantity or 0)
                                  for p in active_products if p.product_type == 'physical')

        # ── Order/revenue stats ───────────────────────────────────────────
        # Bug fix: 'RELEASED' is an EscrowTransaction status, not an Order status —
        # removed it. Revenue = COMPLETED only (funds actually released to vendor),
        # consistent with vendor dashboard and admin GMV stats.
        orders = Order.query.filter_by(vendor_id=sf.vendor_id).all()
        completed_orders = [o for o in orders if (o.status or '').upper() == 'COMPLETED']
        total_gmv        = sum(float(o.total_amount or 0) for o in completed_orders)
        # pending_orders: funded/active but not yet completed — excludes bare PENDING (unpaid)
        pending_orders   = [o for o in orders if (o.status or '').upper() in ('PAID', 'PROCESSING', 'PENDING_DELIVERY', 'SHIPPED', 'DELIVERED')]

        # ── Event stats ───────────────────────────────────────────────────
        events = Event.query.filter_by(vendor_id=sf.vendor_id, is_deleted=False).all()
        live_events      = [e for e in events if e.is_published]
        all_tickets      = TicketPurchase.query.filter(
            TicketPurchase.event_id.in_([e.id for e in events])
        ).all() if events else []
        active_tickets   = [t for t in all_tickets if t.status == 'ACTIVE']
        event_revenue    = sum(float(t.price_paid or 0) for t in active_tickets)

        # ── Trust tier ────────────────────────────────────────────────────
        trust = VendorTrustProfile.query.filter_by(vendor_id=sf.vendor_id).first()
        trust_tier = trust.tier if trust else "BRONZE"

        return jsonify({
            "storefront": {
                "id":             sf.id,
                "store_name":     sf.store_name,
                "store_slug":     sf.store_slug or sf.storefront_link,
                "is_published":   sf.is_published,
                "is_verified":    sf.is_verified,
                "is_pro_verified":getattr(sf, 'is_pro_verified', False),
                "created_at":     sf.created_at.isoformat() if sf.created_at else None,
            },
            "vendor": {
                "id":            vendor.id if vendor else None,
                "name":          (vendor.full_name or vendor.business_name or vendor.email) if vendor else None,
                "email":         vendor.email if vendor else None,
                "phone":         vendor.phone if vendor else None,
                "is_active":     vendor.is_active if vendor else False,
            },
            "products": {
                "total":         len(all_products),
                "active":        len(active_products),
                "inventory_value": round(total_product_value, 2),
            },
            "orders": {
                "total":         len(orders),
                "completed":     len(completed_orders),
                "pending":       len(pending_orders),
                "gmv":           round(total_gmv, 2),
            },
            "events": {
                "total":         len(events),
                "live":          len(live_events),
                "tickets_sold":  len(active_tickets),
                "revenue":       round(event_revenue, 2),
            },
            "trust_tier":    trust_tier,
        }), 200

    except Exception as e:
        logging.error(f"[ADMIN] Error fetching storefront detail: {e}")
        return jsonify({"message": "Failed to load storefront detail"}), 500
