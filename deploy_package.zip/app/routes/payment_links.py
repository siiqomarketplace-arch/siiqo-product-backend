import os
import uuid
import re
import logging
from datetime import datetime, timezone, timedelta
from decimal import Decimal

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db
from app.models.user import User, Storefront, UserRole
from app.models.order import Order, OrderItem
from app.models.escrow import EscrowTransaction, EscrowStatus
from app.models.payment_link import PaymentLink
from app.models.withdrawal import VendorBankAccount
from app.routes.escrow import generate_order_token

payment_links_bp = Blueprint('payment_links', __name__)

def _utcnow():
    return datetime.now(timezone.utc)

def _get_vendor(user_id) -> User | None:
    user = db.session.get(User, int(user_id))
    if not user:
        return None
    if user.role in [UserRole.VENDOR, UserRole.ADMIN] or user.storefront is not None:
        return user
    return None

# ===========================================================================
# VENDOR ENDPOINTS
# ===========================================================================

@payment_links_bp.route('/vendor/payment-links', methods=['POST'])
@jwt_required()
def create_payment_link():
    user_id = get_jwt_identity()
    vendor = _get_vendor(user_id)
    if not vendor:
        return jsonify({"message": "Vendor access required"}), 403
    if not vendor.storefront:
        return jsonify({"message": "Complete vendor onboarding first"}), 403

    data = request.get_json() or {}
    title = (data.get('title') or '').strip()
    description = (data.get('description') or '').strip()
    amount_str = data.get('amount')
    link_type = (data.get('link_type') or 'PAY_LINK').upper()
    buyer_email = (data.get('buyer_email') or '').strip().lower()
    product_type = (data.get('product_type') or 'service').lower()
    if product_type not in ('physical', 'digital', 'service'):
        product_type = 'service'
    file_url = (data.get('file_url') or '').strip() or None

    if not title:
        return jsonify({"message": "Title is required"}), 400

    if link_type not in ['PAY_LINK', 'INVOICE']:
        return jsonify({"message": "Invalid link_type. Allowed: PAY_LINK, INVOICE"}), 400

    # For Invoice, amount is required
    amount = None
    if amount_str is not None:
        try:
            amount = Decimal(str(amount_str))
            if amount <= 0:
                return jsonify({"message": "Amount must be greater than zero"}), 400
        except Exception:
            return jsonify({"message": "Invalid amount format"}), 400
    elif link_type == 'INVOICE':
        return jsonify({"message": "Amount is required for invoice links"}), 400

    # Auto-generate a unique slug
    clean_title = re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-')
    slug = f"{clean_title}-{uuid.uuid4().hex[:6]}"
    # Fallback if title contains no letters/numbers
    if not slug or slug.startswith('-'):
        slug = f"pay-{uuid.uuid4().hex[:10]}"

    new_link = PaymentLink(
        vendor_id=vendor.id,
        link_type=link_type,
        title=title,
        description=description,
        amount=amount,
        buyer_email=buyer_email if buyer_email else None,
        status='ACTIVE',
        slug=slug,
        product_type=product_type,
        file_url=file_url,
    )

    db.session.add(new_link)
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Database error: {str(e)}"}), 500

    return jsonify({
        "status": "success",
        "message": "Payment link created successfully",
        "data": new_link.to_dict()
    }), 201


@payment_links_bp.route('/vendor/payment-links', methods=['GET'])
@jwt_required()
def get_vendor_payment_links():
    user_id = get_jwt_identity()
    vendor = _get_vendor(user_id)
    if not vendor:
        return jsonify({"message": "Vendor access required"}), 403

    links = PaymentLink.query.filter_by(vendor_id=vendor.id).order_by(PaymentLink.created_at.desc()).all()
    
    # Calculate stats per link
    result = []
    for link in links:
        total_payouts = db.session.query(db.func.sum(Order.total_amount)).filter(
            Order.payment_link_id == link.id,
            Order.status.in_(['PAID', 'SHIPPED', 'DELIVERED', 'COMPLETED'])
        ).scalar() or 0
        total_orders = Order.query.filter(
            Order.payment_link_id == link.id,
            Order.status.in_(['PAID', 'SHIPPED', 'DELIVERED', 'COMPLETED'])
        ).count()
        
        d = link.to_dict()
        d['total_revenue'] = str(total_payouts)
        d['total_orders'] = total_orders
        result.append(d)

    return jsonify(result), 200


@payment_links_bp.route('/vendor/payment-links/<int:link_id>', methods=['DELETE'])
@jwt_required()
def delete_payment_link(link_id):
    user_id = get_jwt_identity()
    vendor = _get_vendor(user_id)
    if not vendor:
        return jsonify({"message": "Vendor access required"}), 403

    link = PaymentLink.query.filter_by(id=link_id, vendor_id=vendor.id).first()
    if not link:
        return jsonify({"message": "Payment link not found"}), 404

    # Soft delete / deactivate
    link.status = 'EXPIRED'
    db.session.commit()
    return jsonify({"status": "success", "message": "Payment link deactivated"}), 200


# ===========================================================================
# PUBLIC ENDPOINTS
# ===========================================================================

@payment_links_bp.route('/marketplace/payment-links/<slug>', methods=['GET'])
def get_public_payment_link(slug):
    link = PaymentLink.query.filter_by(slug=slug).first()
    if not link:
        return jsonify({"message": "Payment link not found"}), 404

    sf = link.vendor.storefront if link.vendor else None
    
    return jsonify({
        "link": link.to_dict(),
        "vendor": {
            "store_name": sf.store_name if sf else (link.vendor.full_name if link.vendor else "Unknown Store"),
            "store_logo": sf.store_logo if sf else None,
            "store_slug": sf.store_slug if sf else None,
        }
    }), 200


@payment_links_bp.route('/marketplace/payment-links/<int:link_id>/pay', methods=['POST'])
def pay_payment_link(link_id):
    link = db.session.get(PaymentLink, link_id)
    if not link or link.status == 'EXPIRED':
        return jsonify({"message": "Payment link is inactive or expired."}), 400

    if link.link_type == 'INVOICE' and link.status == 'PAID':
        return jsonify({"message": "This invoice has already been paid."}), 400

    data = request.get_json() or {}
    buyer_name = (data.get('buyer_name') or '').strip()
    buyer_email = (data.get('buyer_email') or '').strip().lower()
    buyer_phone = (data.get('buyer_phone') or '').strip()

    link_product_type = getattr(link, 'product_type', 'service') or 'service'

    if not buyer_name:
        buyer_name = "Guest Buyer"

    # Only physical products strictly require a phone number for courier delivery
    if link_product_type == 'physical' and not buyer_phone:
        return jsonify({"message": "Phone number is required for physical delivery."}), 400

    has_real_email = bool(buyer_email and '@' in buyer_email)

    # ── PHYSICAL PRODUCT GUARD ────────────────────────────────────────────────
    # Pay Links for physical products must never route to Paystack or Flutterwave card.
    # payment_method must be 'bank_transfer' or 'crypto' for physical links.
    payment_method = (data.get('payment_method') or 'card').lower()

    if link_product_type == 'physical' and payment_method in ('card', 'flutterwave'):
        return jsonify({
            "message": (
                "Card payment is not available for physical products. "
                "Please use Bank Transfer or Crypto instead."
            ),
            "code": "PAYSTACK_PHYSICAL_BLOCKED",
        }), 400
    # ─────────────────────────────────────────────────────────────────────────

    # Calculate final amount: use link amount, or custom amount if open link
    if link.amount:
        amount = Decimal(str(link.amount))
    else:
        custom_amt = data.get('custom_amount')
        if custom_amt is None:
            return jsonify({"message": "Amount is required for this payment link"}), 400
        try:
            amount = Decimal(str(custom_amt))
            if amount <= 0:
                return jsonify({"message": "Amount must be greater than zero"}), 400
        except Exception:
            return jsonify({"message": "Invalid amount format"}), 400

    # Resolve buyer account: if exists, link to it; otherwise leave buyer_id as None (Option A: clean guest checkout)
    from app.models.user import User
    buyer_user = User.query.filter_by(email=buyer_email).first() if has_real_email else None
    existing_account = buyer_user is not None  # track if this is a pre-existing Siiqo account

    # Create Direct Order (buyer_id=None for guest, matching cart.py and events.py)
    new_order = Order(
        buyer_id=buyer_user.id if buyer_user else None,
        vendor_id=link.vendor_id,
        total_amount=amount,
        status='PENDING',
        payment_method='ESCROW',
        payment_link_id=link.id,
        buyer_name=buyer_name,
        buyer_email=buyer_email if has_real_email else None,
        buyer_phone=buyer_phone or None,
        delivery_phone=buyer_phone or None,
        delivery_name=buyer_name,
        is_guest=not existing_account,
    )
    db.session.add(new_order)
    db.session.flush()

    # Add order item
    db.session.add(OrderItem(
        order_id=new_order.id,
        product_id=None,
        price_at_purchase=amount,
        quantity=1,
    ))

    # Calculate platform fees (5% standard, 3% for verified pro)
    from app.models.user import User as _User
    _v_user = db.session.get(_User, new_order.vendor_id) if new_order.vendor_id else None
    _now = _utcnow()
    _sf = _v_user.storefront if _v_user else None
    _is_v_pro = bool(
        _sf and _sf.is_pro_verified and (not _sf.pro_verified_expires_at or _sf.pro_verified_expires_at > _now)
    )
    fee_percent = 3.00  # Flat 3% Safe Pay fee for all vendors
    fee_amount = amount * Decimal(str(fee_percent / 100.0))

    # Build the return URL so buyer lands on a proper success/tracking page
    site_url = os.environ.get('SITE_URL', 'https://siiqo.com').rstrip('/')
    import urllib.parse
    return_url = (
        f"{site_url}/pay/success"
        f"?order_id={new_order.id}"
        f"&email={urllib.parse.quote(buyer_email if has_real_email else '')}"
        f"&existing={str(existing_account).lower()}"
    )

    # Initiate payment gateway transaction
    from app.services.escrow import get_escrow_provider

    if payment_method in ('bank_transfer', 'crypto'):
        # ── DAYA path ─────────────────────────────────────────────────────────
        # IMPORTANT: Daya is called FIRST. Order/escrow are only committed to DB
        # AFTER Daya succeeds. This prevents phantom orders on failed Daya calls.
        daya_type = 'crypto_direct' if payment_method == 'crypto' else 'ngn_onramp'
        # Set the correct payment_method on the order immediately so it is
        # accurate from creation — not just after confirmation.
        # Bug fix: the old code set 'CRYPTO' for both paths; bank transfer orders
        # were only corrected inside _handle_crypto_payment_confirmed which runs
        # only on successful payment. Unconfirmed bank-transfer orders stayed
        # labelled 'CRYPTO' permanently.
        new_order.payment_method = 'CRYPTO' if payment_method == 'crypto' else 'DAYA_BANK_TRANSFER'

        try:
            from app.services import daya_service as _daya
            import time

            # 1. Safe name split — never access buyer_user attributes (may be None for guests)
            name_parts = buyer_name.strip().split(' ', 1) if buyer_name else []
            first_name = name_parts[0] if name_parts else buyer_email.split('@')[0] if buyer_email else "Guest"
            last_name  = name_parts[1] if len(name_parts) > 1 else ""

            # 2. Daya requires a real email — use synthetic noreply if buyer skipped email
            daya_email = buyer_email if has_real_email else f"paylink-{new_order.id}@noreply.siiqo.app"

            # 3. Get or create Daya customer
            customer_id = _daya.get_or_create_customer(
                email=daya_email,
                first_name=first_name,
                last_name=last_name,
            )

            # 4. Get a firm exchange rate
            rate_side = "SELL" if daya_type == 'crypto_direct' else "BUY"
            rate_data = _daya.get_rate(asset="USDT", side=rate_side)
            rate = float(rate_data.get("rate", 1500))
            rate_id = rate_data.get("rate_id", "")
            rate_expires_at = rate_data.get("expires_at")

            idempotency_key = f"paylink-{new_order.id}-{daya_type}-{rate_id}-{int(time.time())}"

            # 5. Create the funding account (with one retry)
            if daya_type == 'crypto_direct':
                try:
                    fa = _daya.create_crypto_funding_account(
                        customer_id=str(customer_id),
                        asset="USDT",
                        network="TRC20",
                        rate_id=rate_id,
                        idempotency_key=idempotency_key,
                        developer_fee_pct="0",
                    )
                except RuntimeError as first_exc:
                    logging.warning(f"[PAYLINK DAYA] First crypto attempt failed ({first_exc}), retrying...")
                    time.sleep(0.5)
                    fa = _daya.create_crypto_funding_account(
                        customer_id=str(customer_id),
                        asset="USDT",
                        network="TRC20",
                        rate_id=rate_id,
                        idempotency_key=f"{idempotency_key}-r2",
                        developer_fee_pct="0",
                    )
            else:
                try:
                    fa = _daya.create_ngn_funding_account(
                        customer_id=str(customer_id),
                        amount_ngn=int(round(float(amount))),
                        rate_id=rate_id,
                        idempotency_key=idempotency_key,
                        developer_fee_pct="0",
                    )
                except RuntimeError as first_exc:
                    logging.warning(f"[PAYLINK DAYA] First NGN attempt failed ({first_exc}), retrying...")
                    time.sleep(0.5)
                    fa = _daya.create_ngn_funding_account(
                        customer_id=str(customer_id),
                        amount_ngn=int(round(float(amount))),
                        rate_id=rate_id,
                        idempotency_key=f"{idempotency_key}-r2",
                        developer_fee_pct="0",
                    )

            # ── Daya succeeded — NOW commit order + escrow + DayaPayment ──────
            new_escrow = EscrowTransaction(
                order_id=new_order.id,
                transaction_number=f"ESC-{uuid.uuid4().hex[:12].upper()}",
                status=EscrowStatus.PENDING_PAYMENT,
                amount=float(amount),
                fee_percent=fee_percent,
                fee_amount=float(fee_amount),
            )
            db.session.add(new_escrow)

            instructions = fa.get("instructions", [{}])[0]
            daya_amount  = fa.get("amount")
            final_amount_ngn = float(daya_amount) if (daya_type == 'ngn_onramp' and daya_amount) else float(amount)

            from app.models.withdrawal import DayaPayment
            from datetime import datetime as _dt_parse
            expires_dt = None
            if rate_expires_at:
                try:
                    expires_dt = _dt_parse.fromisoformat(str(rate_expires_at).replace('Z', '+00:00'))
                except Exception:
                    pass

            dp = DayaPayment(
                order_id=new_order.id,
                buyer_id=buyer_user.id if buyer_user else None,
                payment_type=daya_type,
                daya_funding_account_id=str(fa.get('id') or ''),
                daya_rate_id=rate_id,
                amount_ngn=final_amount_ngn,
                rate=rate,
                rate_expires_at=expires_dt,
                status='PENDING',
                bank_name=instructions.get('bank_name'),
                account_number=instructions.get('account_number'),
                account_name=instructions.get('account_name'),
                wallet_address=instructions.get('address') or instructions.get('wallet_address'),
                network=instructions.get('network') or fa.get('chain') or fa.get('network'),
            )
            db.session.add(dp)
            db.session.commit()  # ← single commit: order + escrow + DayaPayment together

            # ── Send guest receipt email only after everything is persisted ───
            if not existing_account and has_real_email:
                try:
                    from app.utils.email import send_siiqo_email
                    order_token = generate_order_token(new_order.id)
                    send_siiqo_email(
                        to_email=buyer_email,
                        subject=f"Your Siiqo Order #{new_order.id} — Receipt & Delivery Tracking",
                        template_name="guest_claim_account",
                        first_name=first_name,
                        order_id=new_order.id,
                        vendor_name=link.vendor.storefront.store_name if link.vendor and link.vendor.storefront else "Vendor",
                        amount=f"₦{float(amount):,.2f}",
                        claim_url=f"{site_url}/auth/signup?email={urllib.parse.quote(buyer_email)}&redirect=/user-profile",
                        otp=order_token[:6].upper(),
                    )
                except Exception as email_err:
                    logging.warning(f"[PAYLINK] Guest receipt email failed for {buyer_email}: {email_err}")

            amount_usd = round(final_amount_ngn / rate, 6)
            conf_url = f"https://siiqo.com/order-confirm/{new_order.id}?token={generate_order_token(new_order.id)}"
            return jsonify({
                "success": True,
                "payment_method": payment_method,
                "order_id": new_order.id,
                "amount": str(amount),
                "existing_account": existing_account,
                "confirmation_url": conf_url,
                "buyer_phone": buyer_phone,
                "buyer_email": buyer_email if has_real_email else "",
                "file_url": link.file_url,
                "product_type": link_product_type,
                "daya": {
                    "bank_name": dp.bank_name,
                    "account_number": dp.account_number,
                    "account_name": dp.account_name,
                    "wallet_address": dp.wallet_address,
                    "network": dp.network,
                    "amount_ngn": final_amount_ngn,
                    "amount_usd": amount_usd,
                    "funding_type": daya_type,
                },
                "status": EscrowStatus.PENDING_PAYMENT,
            }), 200

        except Exception as e:
            logging.error(f"[PAYLINK DAYA] Failed to create Daya funding account: {e}")
            db.session.rollback()
            return jsonify({"message": f"Payment gateway error: {str(e)}"}), 503

    elif payment_method == 'flutterwave':
        # ── FLUTTERWAVE path (digital + service only) ─────────────────────────
        from app.services import flutterwave_service as _flw
        from app.models.withdrawal import VendorBankAccount

        new_order.payment_method = 'FLUTTERWAVE'
        flw_txn_ref = f"FLW-PL-{new_order.id}-{uuid.uuid4().hex[:8].upper()}"

        # Check vendor Flutterwave subaccount
        bank_acc = VendorBankAccount.query.filter_by(vendor_id=link.vendor_id, is_default=True).first() or \
                   VendorBankAccount.query.filter_by(vendor_id=link.vendor_id).first()
        flw_subaccount_id = bank_acc.flw_subaccount_id if bank_acc else None

        flw_res = _flw.initiate_payment(
            order_id=str(new_order.id),
            listed_price_ngn=float(amount),
            siiqo_fee_ngn=float(fee_amount),
            buyer_email=buyer_email if has_real_email else f"guest-{new_order.id}@siiqo.com",
            buyer_name=buyer_name or "Guest Buyer",
            buyer_phone=buyer_phone or "",
            flw_subaccount_id=flw_subaccount_id,
            tx_ref=flw_txn_ref,
            redirect_url=return_url,
            is_international=False,
            narration=f"Payment for {link.title or 'Siiqo Item'}",
        )

        if not flw_res.get("success"):
            db.session.rollback()
            return jsonify({"message": flw_res.get("error_message") or "Flutterwave payment initialization failed"}), 400

        new_escrow = EscrowTransaction(
            order_id=new_order.id,
            transaction_number=flw_txn_ref,
            status=EscrowStatus.PENDING_PAYMENT,
            amount=float(amount),
            fee_percent=fee_percent,
            fee_amount=float(fee_amount),
            payment_link=flw_res["payment_link"],
            payscrow_transaction_id=flw_txn_ref,
            payscrow_ref=flw_txn_ref,
        )
        db.session.add(new_escrow)
        db.session.commit()

        conf_url = f"https://siiqo.com/order-confirm/{new_order.id}?token={generate_order_token(new_order.id)}"
        return jsonify({
            "success": True,
            "paymentLink": flw_res.get("payment_link"),
            "transactionNumber": flw_txn_ref,
            "amount": str(flw_res.get("buyer_total", amount)),
            "status": EscrowStatus.PENDING_PAYMENT,
            "order_id": new_order.id,
            "existing_account": existing_account,
            "confirmation_url": conf_url,
            "buyer_phone": buyer_phone,
            "buyer_email": buyer_email if has_real_email else "",
            "file_url": link.file_url,
            "product_type": link_product_type,
        }), 200

    else:
        # ── PAYSTACK / CARD path (digital + service only) ──────────────────────
        new_order.payment_method = 'ESCROW'
        # Use a PL- prefixed reference so the webhook can identify Pay Link orders
        import uuid as _pl_uuid
        pl_txn_ref = f"PL-{new_order.id}-{_pl_uuid.uuid4().hex[:8].upper()}"
        provider = get_escrow_provider()
        result = provider.initiate_transaction(
            [new_order],
            existing_txn_number=pl_txn_ref,
            return_url=return_url,
        )
        if not result.get("success"):
            db.session.rollback()
            return jsonify({"message": result.get("error_message") or "Payment gateway initialization failed"}), 400

        new_escrow = EscrowTransaction(
            order_id=new_order.id,
            transaction_number=result['transaction_number'],
            status=EscrowStatus.PENDING_PAYMENT,
            amount=float(amount),
            fee_percent=fee_percent,
            fee_amount=float(fee_amount),
            payment_link=result['payment_link'],
            payscrow_transaction_id=result['provider_transaction_id'],
            payscrow_ref=result['provider_reference'],
        )
        db.session.add(new_escrow)
        db.session.commit()

        conf_url = f"https://siiqo.com/order-confirm/{new_order.id}?token={generate_order_token(new_order.id)}"
        return jsonify({
            "success": True,
            "paymentLink": result.get('payment_link'),
            "transactionNumber": result.get('transaction_number'),
            "amount": str(amount),
            "status": EscrowStatus.PENDING_PAYMENT,
            "order_id": new_order.id,
            "existing_account": existing_account,
            "confirmation_url": conf_url,
            "buyer_phone": buyer_phone,
            "buyer_email": buyer_email if has_real_email else "",
            "file_url": link.file_url,
            "product_type": link_product_type,
        }), 200
